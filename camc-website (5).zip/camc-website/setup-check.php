<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CAMC — Server Setup Checker</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Lato:wght@400;700&display=swap');
  *{margin:0;padding:0;box-sizing:border-box;}
  body{font-family:'Lato',sans-serif;background:#0A1628;color:#fff;padding:2rem;min-height:100vh;}
  h1{font-family:'Cinzel',serif;color:#C9A84C;font-size:1.8rem;margin-bottom:0.5rem;}
  .sub{color:rgba(255,255,255,0.5);font-size:13px;margin-bottom:2rem;}
  .card{background:#132040;border-radius:10px;padding:1.5rem;margin-bottom:1.5rem;border:1px solid rgba(201,168,76,0.2);}
  .card h2{font-family:'Cinzel',serif;font-size:14px;letter-spacing:2px;color:#C9A84C;text-transform:uppercase;margin-bottom:1rem;}
  .check{display:flex;align-items:flex-start;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05);}
  .check:last-child{border-bottom:none;}
  .icon{font-size:1.1rem;flex-shrink:0;margin-top:1px;}
  .label{font-weight:700;font-size:13px;margin-bottom:2px;}
  .val{font-size:12px;color:rgba(255,255,255,0.5);}
  .ok{color:#22c55e;}.warn{color:#f59e0b;}.err{color:#ef4444;}
  .fix-box{background:rgba(201,168,76,0.08);border:1px solid rgba(201,168,76,0.3);border-radius:8px;padding:1.2rem;margin-top:1rem;}
  .fix-box h3{color:#C9A84C;font-size:13px;font-weight:700;margin-bottom:0.5rem;}
  .fix-box p,.fix-box li{color:rgba(255,255,255,0.7);font-size:13px;line-height:1.7;}
  .fix-box ol{padding-left:1.2rem;}
  .delete-note{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:6px;padding:1rem;margin-top:2rem;color:#fca5a5;font-size:13px;}
  code{background:rgba(201,168,76,0.15);color:#C9A84C;padding:1px 6px;border-radius:3px;font-size:12px;}
</style>
</head>
<body>

<h1>⛪ CAMC — Server Setup Checker</h1>
<p class="sub">Diagnosing your hosting environment for camc-website · Run this after uploading files</p>

<?php
function check($label, $pass, $val, $fix = '') {
    $icon = $pass === true ? '✅' : ($pass === 'warn' ? '⚠️' : '❌');
    $cls  = $pass === true ? 'ok' : ($pass === 'warn' ? 'warn' : 'err');
    echo '<div class="check">';
    echo '<span class="icon">' . $icon . '</span>';
    echo '<div><div class="label ' . $cls . '">' . $label . '</div>';
    echo '<div class="val">' . htmlspecialchars($val) . '</div>';
    if ($fix) echo '<div class="fix-box" style="margin-top:8px;"><p>' . $fix . '</p></div>';
    echo '</div></div>';
}
?>

<!-- PHP INFO -->
<div class="card">
  <h2>PHP Environment</h2>
  <?php
  $phpVer = phpversion();
  $phpOk = version_compare($phpVer, '7.4', '>=');
  check('PHP Version', $phpOk, $phpVer . ($phpOk ? ' ✓ Compatible' : ' ✗ Too old — need 7.4+'),
    $phpOk ? '' : 'In cPanel → <b>MultiPHP Manager</b> → select your domain → set to PHP 7.4 or 8.x → Apply.');

  check('PHP Sessions', function_exists('session_start'), 'session_start() — ' . (function_exists('session_start') ? 'Available' : 'NOT available'));
  check('JSON Support', function_exists('json_encode'), 'json_encode() — ' . (function_exists('json_encode') ? 'Available' : 'NOT available'));
  check('File Upload', ini_get('file_uploads') ? true : false, 'file_uploads = ' . (ini_get('file_uploads') ? 'On' : 'Off'));
  check('Upload Max Size', true, 'upload_max_filesize = ' . ini_get('upload_max_filesize'));
  check('Post Max Size', true, 'post_max_size = ' . ini_get('post_max_size'));
  check('Memory Limit', true, 'memory_limit = ' . ini_get('memory_limit'));
  ?>
</div>

<!-- DIRECTORY PERMISSIONS -->
<div class="card">
  <h2>Directory Permissions</h2>
  <?php
  $dirs = [
    'Root (camc-website)' => __DIR__,
    'assets/'             => __DIR__ . '/assets',
    'assets/images/'      => __DIR__ . '/assets/images',
    'assets/images/gallery/' => __DIR__ . '/assets/images/gallery',
    'includes/'           => __DIR__ . '/includes',
    'includes/data/'      => __DIR__ . '/includes/data',
    'pages/'              => __DIR__ . '/pages',
    'admin/'              => __DIR__ . '/admin',
    'cgi-bin/'            => __DIR__ . '/cgi-bin',
  ];
  foreach ($dirs as $name => $path) {
    if (!file_exists($path)) {
      check($name, false, 'MISSING — directory does not exist',
        'Create this folder in cPanel File Manager. Right-click → New Folder → name it <code>' . basename($path) . '</code>');
    } else {
      $perms = substr(sprintf('%o', fileperms($path)), -4);
      $writable = is_writable($path);
      $needsWrite = in_array($name, ['assets/images/gallery/', 'includes/data/']);
      if ($needsWrite && !$writable) {
        check($name, false, 'Exists · Permissions: ' . $perms . ' · NOT WRITABLE — uploads will fail',
          'In cPanel File Manager: right-click the folder → <b>Change Permissions</b> → set to <b>755</b> → Save.');
      } else {
        check($name, true, 'Exists · Permissions: ' . $perms . ($writable ? ' · Writable ✓' : ' · Read-only'));
      }
    }
  }
  ?>
</div>

<!-- KEY FILES -->
<div class="card">
  <h2>Key Files Check</h2>
  <?php
  $files = [
    'index.php'           => __DIR__ . '/index.php',
    '.htaccess'           => __DIR__ . '/.htaccess',
    'assets/css/style.css'=> __DIR__ . '/assets/css/style.css',
    'assets/js/main.js'   => __DIR__ . '/assets/js/main.js',
    'includes/header.php' => __DIR__ . '/includes/header.php',
    'includes/footer.php' => __DIR__ . '/includes/footer.php',
    'admin/login.php'     => __DIR__ . '/admin/login.php',
    'pages/gallery.php'   => __DIR__ . '/pages/gallery.php',
    'pages/branches.php'  => __DIR__ . '/pages/branches.php',
  ];
  foreach ($files as $name => $path) {
    if (file_exists($path)) {
      check($name, true, 'Found · ' . number_format(filesize($path)) . ' bytes');
    } else {
      check($name, false, 'MISSING',
        'This file is missing. Re-upload and extract the ZIP. Make sure you extracted INTO public_html, not into a subfolder.');
    }
  }
  ?>
</div>

<!-- EVENT IMAGES -->
<div class="card">
  <h2>Event Photos (Gallery)</h2>
  <?php
  $imgDir = __DIR__ . '/assets/images/';
  $imgs = glob($imgDir . 'DSC_*.jpg');
  if (count($imgs) >= 13) {
    check('Event Photos', true, count($imgs) . ' DSC_ images found in assets/images/');
  } else {
    check('Event Photos', 'warn', count($imgs) . '/13 DSC_ images found',
      'Some event photos may be missing. Re-upload the ZIP and make sure all DSC_*.jpg files are in assets/images/');
  }
  $galleryDir = __DIR__ . '/assets/images/gallery/';
  $galleryExists = is_dir($galleryDir);
  check('Gallery Upload Folder', $galleryExists, $galleryDir . ($galleryExists ? ' exists' : ' MISSING'),
    'Create the folder <code>assets/images/gallery</code> in File Manager and set permissions to 755.');
  ?>
</div>

<!-- SERVER INFO -->
<div class="card">
  <h2>Server Information</h2>
  <?php
  check('Server Software', true, $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown');
  check('Document Root', true, $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown');
  check('Script Path', true, __DIR__);
  check('mod_rewrite', function_exists('apache_get_modules') && in_array('mod_rewrite', apache_get_modules()) ? true : 'warn',
    function_exists('apache_get_modules') ? (in_array('mod_rewrite', apache_get_modules()) ? 'Enabled' : 'Not detected') : 'Cannot detect (FastCGI mode — usually fine)',
    '');
  ?>
</div>

<!-- QUICK FIX GUIDE -->
<div class="card">
  <h2>Quick Fix Guide</h2>
  <div class="fix-box">
    <h3>If files are in public_html/camc-website/ instead of public_html/</h3>
    <ol>
      <li>In File Manager, open <code>public_html/camc-website/</code></li>
      <li>Select ALL files (Ctrl+A)</li>
      <li>Click <b>Move</b> → destination: <code>/public_html/</code></li>
      <li>Then delete the empty <code>camc-website</code> folder</li>
    </ol>
  </div>
  <div class="fix-box" style="margin-top:1rem;">
    <h3>If you get a 500 Error</h3>
    <ol>
      <li>Go to cPanel → <b>MultiPHP Manager</b> → set domain to PHP 8.1 or 8.2</li>
      <li>Check that <code>.htaccess</code> is in <code>public_html/</code></li>
      <li>Check <code>public_html/error_log</code> file for the exact error</li>
    </ol>
  </div>
  <div class="fix-box" style="margin-top:1rem;">
    <h3>If photo uploads fail in Admin Panel</h3>
    <ol>
      <li>Right-click <code>assets/images/gallery</code> → Change Permissions → <b>755</b></li>
      <li>Right-click <code>includes/data</code> → Change Permissions → <b>755</b></li>
    </ol>
  </div>
  <div class="fix-box" style="margin-top:1rem;">
    <h3>Admin Login</h3>
    <p>URL: <code>yourdomain.com/admin/login.php</code><br>
    Contact your system administrator for login credentials.</p>
  </div>
</div>

<div class="delete-note">
  🔒 <strong>Security:</strong> Delete this file (<code>setup-check.php</code>) after you have confirmed everything is working. It reveals server information that should not be public.
</div>

</body>
</html>
