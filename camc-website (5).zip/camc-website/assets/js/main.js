// ===== CAMC WEBSITE MAIN JS =====

// Nav toggle
const navToggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('.nav-links');
if (navToggle) {
  navToggle.addEventListener('click', () => navLinks.classList.toggle('open'));
}

// Active nav link
const currentPage = window.location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.nav-links a').forEach(link => {
  if (link.getAttribute('href') === currentPage) link.classList.add('active');
});

// Lightbox
const galleryItems = document.querySelectorAll('.gallery-item');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
let currentIndex = 0;
const imgSources = [];

if (galleryItems.length && lightbox) {
  galleryItems.forEach((item, i) => {
    const img = item.querySelector('img');
    imgSources.push(img.src);
    item.addEventListener('click', () => {
      currentIndex = i;
      lightboxImg.src = imgSources[i];
      lightbox.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
  });

  document.getElementById('lb-close').addEventListener('click', closeLightbox);
  document.getElementById('lb-prev').addEventListener('click', () => navigate(-1));
  document.getElementById('lb-next').addEventListener('click', () => navigate(1));
  lightbox.addEventListener('click', (e) => { if (e.target === lightbox) closeLightbox(); });

  document.addEventListener('keydown', (e) => {
    if (!lightbox.classList.contains('active')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') navigate(-1);
    if (e.key === 'ArrowRight') navigate(1);
  });

  function navigate(dir) {
    currentIndex = (currentIndex + dir + imgSources.length) % imgSources.length;
    lightboxImg.src = imgSources[currentIndex];
  }

  function closeLightbox() {
    lightbox.classList.remove('active');
    document.body.style.overflow = '';
  }
}

// Counter animation
function animateCounters() {
  document.querySelectorAll('.counter').forEach(el => {
    const target = parseInt(el.dataset.target);
    let current = 0;
    const step = target / 60;
    const timer = setInterval(() => {
      current = Math.min(current + step, target);
      el.textContent = Math.floor(current) + (el.dataset.suffix || '');
      if (current >= target) clearInterval(timer);
    }, 30);
  });
}

// Intersection observer for animations
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      if (entry.target.classList.contains('stats-section')) animateCounters();
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.stats-section, .program-card, .branch-card').forEach(el => observer.observe(el));

// Scroll nav transparency
window.addEventListener('scroll', () => {
  const nav = document.querySelector('nav');
  if (nav) nav.style.background = window.scrollY > 50 ? 'rgba(10,22,40,0.98)' : 'rgba(10,22,40,0.97)';
});
