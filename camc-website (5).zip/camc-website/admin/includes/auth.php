<?php
session_start();
if (!isset($_SESSION['admin_role'])) {
    header('Location: ../login.php');
    exit;
}
$role = $_SESSION['admin_role'];
$name = $_SESSION['admin_name'];
$branch = $_SESSION['admin_branch'] ?? 'All Branches';

function admin_nav($base = '../../') {
    global $role, $branch;
    $prefix = $role === 'super' ? $base . 'super/' : $base . 'branch/';
    return [
        'Dashboard' => ['icon' => '📊', 'url' => $prefix . 'dashboard.php'],
        'Sermons'   => ['icon' => '🎙', 'url' => $prefix . 'sermons.php'],
        'Events'    => ['icon' => '📅', 'url' => $prefix . 'events.php'],
        'Gallery'   => ['icon' => '🖼', 'url' => $prefix . 'gallery.php'],
        'Branches'  => $role === 'super' ? ['icon' => '⛪', 'url' => $base . 'super/branches.php'] : null,
        'Users'     => $role === 'super' ? ['icon' => '👥', 'url' => $base . 'super/users.php'] : null,
        'Settings'  => ['icon' => '⚙', 'url' => $prefix . 'settings.php'],
    ];
}
?>
