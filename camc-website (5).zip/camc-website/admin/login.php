<?php
session_start();

// Redirect if already logged in
if (isset($_SESSION['admin_role'])) {
    if ($_SESSION['admin_role'] === 'super') header('Location: super/dashboard.php');
    else header('Location: branch/dashboard.php');
    exit;
}

$error = '';

// Default credentials (change in production)
$users = [
    'superadmin' => ['password' => 'camc2026!super', 'role' => 'super', 'name' => 'Super Admin'],
    'branch1'    => ['password' => 'camc2026!branch1', 'role' => 'branch', 'name' => 'Abule-Egba Branch', 'branch' => 'Abule-Egba'],
    'branch2'    => ['password' => 'camc2026!branch2', 'role' => 'branch', 'name' => 'Mushin Branch', 'branch' => 'Idi-Oro Mushin'],
    'branch3'    => ['password' => 'camc2026!branch3', 'role' => 'branch', 'name' => 'Ibadan Branch', 'branch' => 'Ibadan Central'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        $user = $users[$username];
        $_SESSION['admin_user'] = $username;
        $_SESSION['admin_name'] = $user['name'];
        $_SESSION['admin_role'] = $user['role'];
        if (isset($user['branch'])) $_SESSION['admin_branch'] = $user['branch'];
        
        if ($user['role'] === 'super') header('Location: super/dashboard.php');
        else header('Location: branch/dashboard.php');
        exit;
    } else {
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login - CAMC</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="login-page">
  <div class="login-box">
    <div style="text-align:center; margin-bottom:2rem;">
      <div style="width:80px; height:80px; border-radius:50%; overflow:hidden; border:3px solid var(--gold); margin:0 auto 1rem; box-shadow:0 0 30px rgba(201,168,76,0.4); background:#fff;">
        <img src="../assets/images/camc-logo.jpg" alt="CAMC Logo" style="width:100%;height:100%;object-fit:cover;">
      </div>
      <h2>Admin Portal</h2>
      <p class="sub">Christ Apostolic Mission Church</p>
    </div>

    <?php if ($error): ?>
    <div style="background:rgba(239,68,68,0.15); border:1px solid #ef4444; color:#ef4444; padding:0.75rem 1rem; border-radius:6px; font-size:13px; margin-bottom:1.5rem;">
      ⚠ <?php echo $error; ?>
    </div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" placeholder="Enter username" required autocomplete="username">
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Enter password" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn btn-gold" style="width:100%; margin-top:0.5rem;">Login to Dashboard</button>
    </form>

    <p style="text-align:center; margin-top:1.5rem; font-size:12px; color:rgba(255,255,255,0.3);">
      <a href="../index.php" style="color:var(--gold);">← Back to Main Website</a>
    </p>


  </div>
</div>
</body>
</html>
