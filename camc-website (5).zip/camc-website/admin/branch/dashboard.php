<?php
session_start();
if (!isset($_SESSION['admin_role']) || $_SESSION['admin_role'] !== 'branch') { header('Location: ../login.php'); exit; }
$name = $_SESSION['admin_name'];
$branch = $_SESSION['admin_branch'] ?? 'My Branch';

$dataDir = '../../includes/data/';
function readData($file, $dir) { $p = $dir.$file; return file_exists($p) ? json_decode(file_get_contents($p), true) ?: [] : []; }
$sermons = array_filter(readData('sermons.json', $dataDir), fn($s) => ($s['branch'] ?? '') === $branch || ($s['branch'] ?? '') === 'All Branches');
$events = array_filter(readData('events.json', $dataDir), fn($e) => ($e['branch'] ?? '') === $branch || ($e['branch'] ?? '') === 'All Branches');
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Branch Admin Dashboard - CAMC</title>
<link rel="stylesheet" href="../../assets/css/style.css">
<style>body{background:#0a1628;margin:0;}</style>
</head><body class="admin-body"><div class="admin-layout">
  <div class="admin-sidebar">
    <div class="admin-sidebar-logo">
      <div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;font-weight:700;">⛪ Branch Admin</div>
      <div style="font-size:11px;color:rgba(255,255,255,0.4);margin-top:3px;"><?php echo htmlspecialchars($branch); ?></div>
    </div>
    <nav class="admin-nav">
      <a href="dashboard.php" class="admin-nav-item active">📊 Dashboard</a>
      <a href="sermons.php" class="admin-nav-item">🎙 Sermons</a>
      <a href="events.php" class="admin-nav-item">📅 Events</a>
      <a href="gallery.php" class="admin-nav-item">🖼 Gallery</a>
      <a href="settings.php" class="admin-nav-item">⚙ Branch Info</a>
      <div style="border-top:1px solid rgba(201,168,76,0.15);margin:1rem 0;"></div>
      <a href="../../index.php" class="admin-nav-item" target="_blank">🌐 View Website</a>
      <a href="../logout.php" class="admin-nav-item" style="color:#ef4444;">🚪 Logout</a>
    </nav>
  </div>
  <div class="admin-main">
    <div class="admin-topbar">
      <div><h2>Branch Dashboard</h2><p style="font-size:12px;color:rgba(255,255,255,0.4);margin-top:2px;"><?php echo htmlspecialchars($branch); ?></p></div>
      <a href="../logout.php" class="btn btn-gold" style="font-size:11px;padding:8px 16px;">Logout</a>
    </div>
    <div style="background:linear-gradient(135deg,rgba(201,168,76,0.15),rgba(139,26,26,0.1));border:1px solid rgba(201,168,76,0.2);border-radius:10px;padding:1.5rem 2rem;margin-bottom:2rem;display:flex;align-items:center;justify-content:space-between;">
      <div><h3 style="font-family:'Cinzel',serif;color:var(--white);font-size:1.1rem;">Welcome, <?php echo htmlspecialchars($name); ?>!</h3><p style="color:rgba(255,255,255,0.5);font-size:13px;"><?php echo htmlspecialchars($branch); ?> · <?php echo date('l, F j, Y'); ?></p></div>
      <div style="font-size:2rem;">⛪</div>
    </div>
    <div class="admin-cards">
      <div class="admin-card"><div class="card-num"><?php echo count($sermons); ?></div><div class="card-label">Branch Sermons</div></div>
      <div class="admin-card"><div class="card-num"><?php echo count($events); ?></div><div class="card-label">Branch Events</div></div>
    </div>
    <div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;letter-spacing:2px;text-transform:uppercase;margin-bottom:1rem;">Quick Actions</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:1rem;margin-bottom:2rem;">
      <a href="gallery.php" style="background:var(--navy-light);border:1px solid rgba(201,168,76,0.2);border-radius:8px;padding:1.2rem;text-align:center;text-decoration:none;display:block;transition:all 0.2s;">
        <div style="font-size:1.8rem;margin-bottom:0.5rem;">🖼</div><div style="font-size:12px;font-weight:700;letter-spacing:1px;color:rgba(255,255,255,0.7);text-transform:uppercase;">Upload Photos</div>
      </a>
      <a href="sermons.php" style="background:var(--navy-light);border:1px solid rgba(201,168,76,0.2);border-radius:8px;padding:1.2rem;text-align:center;text-decoration:none;display:block;">
        <div style="font-size:1.8rem;margin-bottom:0.5rem;">🎙</div><div style="font-size:12px;font-weight:700;letter-spacing:1px;color:rgba(255,255,255,0.7);text-transform:uppercase;">Add Sermon</div>
      </a>
      <a href="events.php" style="background:var(--navy-light);border:1px solid rgba(201,168,76,0.2);border-radius:8px;padding:1.2rem;text-align:center;text-decoration:none;display:block;">
        <div style="font-size:1.8rem;margin-bottom:0.5rem;">📅</div><div style="font-size:12px;font-weight:700;letter-spacing:1px;color:rgba(255,255,255,0.7);text-transform:uppercase;">Add Event</div>
      </a>
    </div>
  </div>
</div></body></html>
