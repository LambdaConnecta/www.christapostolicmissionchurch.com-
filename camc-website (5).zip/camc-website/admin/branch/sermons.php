<?php
session_start();
if (!isset($_SESSION['admin_role.*branch') { header('Location: ../login.php'); exit; }

$dataDir = '../../includes/data/';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
$sermonsFile = $dataDir . 'sermons.json';
$sermons = file_exists($sermonsFile) ? json_decode(file_get_contents($sermonsFile), true) : [];

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        $sermons[] = [
            'id' => time(),
            'title' => htmlspecialchars($_POST['title'] ?? ''),
            'preacher' => htmlspecialchars($_POST['preacher'] ?? ''),
            'date' => $_POST['date'] ?? date('Y-m-d'),
            'scripture' => htmlspecialchars($_POST['scripture'] ?? ''),
            'description' => htmlspecialchars($_POST['description'] ?? ''),
            'url' => htmlspecialchars($_POST['url'] ?? ''),
            'branch' => htmlspecialchars($_POST['branch'] ?? 'All Branches'),
        ];
        file_put_contents($sermonsFile, json_encode($sermons));
        $msg = '<div style="background:rgba(34,197,94,0.15);border:1px solid #22c55e;color:#22c55e;padding:.75rem;border-radius:6px;margin-bottom:1rem;">✅ Sermon added!</div>';
    }
}
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    $sermons = array_values(array_filter($sermons, fn($s) => $s['id'] != $delId));
    file_put_contents($sermonsFile, json_encode($sermons));
    header('Location: sermons.php'); exit;
}
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sermons - CAMC Admin</title>
<link rel="stylesheet" href="../../assets/css/style.css">
<style>body{background:#0a1628;margin:0;}</style>
</head><body class="admin-body"><div class="admin-layout">
  <div class="admin-sidebar">
    <div class="admin-sidebar-logo"><div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;font-weight:700;">⛪ Branch Admin</div></div>
    <nav class="admin-nav">
      <a href="dashboard.php" class="admin-nav-item">📊 Dashboard</a>
      <a href="sermons.php" class="admin-nav-item active">🎙 Sermons</a>
      <a href="events.php" class="admin-nav-item">📅 Events</a>
      <a href="gallery.php" class="admin-nav-item">🖼 Gallery</a>
      <a href="branches.php" class="admin-nav-item">⛪ Branches</a>
      <a href="users.php" class="admin-nav-item">👥 Users</a>
      <div style="border-top:1px solid rgba(201,168,76,0.15);margin:1rem 0;"></div>
      <a href="../../index.php" class="admin-nav-item" target="_blank">🌐 View Website</a>
      <a href="../logout.php" class="admin-nav-item" style="color:#ef4444;">🚪 Logout</a>
    </nav>
  </div>
  <div class="admin-main">
    <div class="admin-topbar"><h2>Sermons</h2><a href="#add-form" class="btn btn-gold" style="font-size:11px;padding:8px 16px;">+ Add Sermon</a></div>
    <?php echo $msg; ?>

    <!-- Add Form -->
    <div id="add-form" style="background:var(--navy-light);border-radius:10px;padding:2rem;margin-bottom:2rem;border:1px solid rgba(201,168,76,0.15);">
      <div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;letter-spacing:2px;margin-bottom:1.5rem;">ADD SERMON</div>
      <form method="POST">
        <input type="hidden" name="action" value="add">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
          <div class="form-group"><label>Sermon Title</label><input type="text" name="title" required placeholder="Title of message"></div>
          <div class="form-group"><label>Preacher</label><input type="text" name="preacher" required placeholder="Name of minister"></div>
          <div class="form-group"><label>Date</label><input type="date" name="date" value="<?php echo date('Y-m-d'); ?>"></div>
          <div class="form-group"><label>Scripture Reference</label><input type="text" name="scripture" placeholder="e.g. John 3:16"></div>
          <div class="form-group"><label>Branch</label><select name="branch"><option>All Branches</option><option>Abule-Egba HQ</option><option>Idi-Oro Mushin</option><option>Ibadan Central</option></select></div>
          <div class="form-group"><label>Video/Audio URL (optional)</label><input type="url" name="url" placeholder="YouTube or audio link"></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description" placeholder="Brief description of the message"></textarea></div>
        <button type="submit" class="btn btn-gold">Add Sermon</button>
      </form>
    </div>

    <!-- List -->
    <?php if (empty($sermons)): ?>
    <div style="text-align:center;padding:3rem;color:rgba(255,255,255,0.3);">No sermons yet. Add your first sermon above.</div>
    <?php else: ?>
    <table class="admin-table">
      <thead><tr><th>Title</th><th>Preacher</th><th>Date</th><th>Branch</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach(array_reverse($sermons) as $s): ?>
        <tr>
          <td style="font-weight:700;color:var(--white);"><?php echo htmlspecialchars($s['title']); ?><br><span style="font-size:11px;color:var(--gold);"><?php echo htmlspecialchars($s['scripture']); ?></span></td>
          <td><?php echo htmlspecialchars($s['preacher']); ?></td>
          <td><?php echo $s['date']; ?></td>
          <td><span class="badge badge-green"><?php echo htmlspecialchars($s['branch']); ?></span></td>
          <td><a href="sermons.php?delete=<?php echo $s['id']; ?>" onclick="return confirm('Delete?')" style="color:#ef4444;font-size:12px;font-weight:700;">Delete</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div></body></html>
