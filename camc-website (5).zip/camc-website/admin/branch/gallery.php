<?php
session_start();
if (!isset($_SESSION['admin_role.*branch') {
    header('Location: ../login.php'); exit;
}

$dataDir = '../../includes/data/';
$uploadDir = '../../assets/images/gallery/';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

$galleryFile = $dataDir . 'gallery.json';
$gallery = file_exists($galleryFile) ? json_decode(file_get_contents($galleryFile), true) : [];

// Pre-populate with existing event photos
if (empty($gallery)) {
    $gallery = [
        ['id'=>1,'file'=>'../../assets/images/DSC_1368.jpg','caption'=>'Woman Kneeling in Prayer','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>2,'file'=>'../../assets/images/DSC_1371.jpg','caption'=>'Congregation Dancing','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>3,'file'=>'../../assets/images/DSC_1375.jpg','caption'=>'Hands Raised in Worship','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>4,'file'=>'../../assets/images/DSC_1381.jpg','caption'=>'Young Drummer','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>5,'file'=>'../../assets/images/DSC_1384.jpg','caption'=>'Saxophonists','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>6,'file'=>'../../assets/images/DSC_1388.jpg','caption'=>'Drum Kit Close-Up','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>7,'file'=>'../../assets/images/DSC_1393.jpg','caption'=>'Leadership on Stage','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>8,'file'=>'../../assets/images/DSC_1396.jpg','caption'=>'President in Worship','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>9,'file'=>'../../assets/images/DSC_1404.jpg','caption'=>'Women with Handkerchiefs','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>10,'file'=>'../../assets/images/DSC_1407.jpg','caption'=>'Prayer Moment','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>11,'file'=>'../../assets/images/DSC_1421.jpg','caption'=>'Full Congregation','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>12,'file'=>'../../assets/images/DSC_1423.jpg','caption'=>'Woman Raising Hands','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
        ['id'=>13,'file'=>'../../assets/images/DSC_1439.jpg','caption'=>'Choir Before Altar','event'=>'January Salvation Vigil 2026','date'=>'2026-01-26','branch'=>'Abule-Egba HQ'],
    ];
    file_put_contents($galleryFile, json_encode($gallery));
}

$msg = '';
// Handle upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['photo'])) {
    $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $files = $_FILES['photo'];
    $uploaded = 0;
    
    for ($i = 0; $i < count($files['name']); $i++) {
        if ($files['error'][$i] === 0 && in_array($files['type'][$i], $allowed)) {
            $ext = pathinfo($files['name'][$i], PATHINFO_EXTENSION);
            $newName = 'gallery_' . time() . '_' . $i . '.' . $ext;
            $dest = $uploadDir . $newName;
            
            if (move_uploaded_file($files['tmp_name'][$i], $dest)) {
                $gallery[] = [
                    'id' => time() + $i,
                    'file' => 'assets/images/gallery/' . $newName,
                    'caption' => htmlspecialchars($_POST['caption'] ?? 'Event Photo'),
                    'event' => htmlspecialchars($_POST['event'] ?? ''),
                    'date' => $_POST['date'] ?? date('Y-m-d'),
                    'branch' => $_POST['branch'] ?? 'All Branches',
                ];
                $uploaded++;
            }
        }
    }
    
    if ($uploaded > 0) {
        file_put_contents($galleryFile, json_encode($gallery));
        $msg = '<div style="background:rgba(34,197,94,0.15); border:1px solid #22c55e; color:#22c55e; padding:0.75rem; border-radius:6px; margin-bottom:1rem;">✅ ' . $uploaded . ' photo(s) uploaded successfully!</div>';
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    $gallery = array_filter($gallery, fn($g) => $g['id'] != $delId);
    $gallery = array_values($gallery);
    file_put_contents($galleryFile, json_encode($gallery));
    header('Location: gallery.php?deleted=1'); exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gallery Management - CAMC Admin</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
  <style>
    body { background:#0a1628; margin:0; }
    .upload-zone { border: 2px dashed rgba(201,168,76,0.4); border-radius:10px; padding:2.5rem; text-align:center; cursor:pointer; transition:all 0.2s; background:rgba(201,168,76,0.04); }
    .upload-zone:hover { border-color:var(--gold); background:rgba(201,168,76,0.08); }
    .upload-zone input[type=file] { display:none; }
    .upload-zone .icon { font-size:2.5rem; margin-bottom:0.75rem; }
    .upload-zone p { color:rgba(255,255,255,0.5); font-size:13px; }
    .upload-zone .sub { font-size:11px; color:rgba(255,255,255,0.3); margin-top:4px; }
    .photo-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(200px,1fr)); gap:12px; margin-top:1.5rem; }
    .photo-item { position:relative; border-radius:8px; overflow:hidden; aspect-ratio:4/3; background:var(--navy-light); }
    .photo-item img { width:100%; height:100%; object-fit:cover; display:block; }
    .photo-actions { position:absolute; inset:0; background:rgba(10,22,40,0.8); opacity:0; transition:opacity 0.2s; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:8px; }
    .photo-item:hover .photo-actions { opacity:1; }
    .photo-caption { position:absolute; bottom:0; left:0; right:0; background:linear-gradient(to top, rgba(10,22,40,0.9), transparent); padding:0.75rem; font-size:11px; color:var(--white); }
    .photo-caption strong { display:block; color:var(--gold); font-size:10px; letter-spacing:1px; }
  </style>
</head>
<body class="admin-body">
<div class="admin-layout">
  <div class="admin-sidebar">
    <div class="admin-sidebar-logo">
      <div style="display:flex; align-items:center; gap:10px;">
        <div class="nav-logo-circle" style="width:38px;height:38px;font-size:11px;">CAMC</div>
        <div><div style="font-family:'Cinzel',serif; color:var(--gold); font-size:13px; font-weight:700;">Branch Admin</div><div style="font-size:11px; color:rgba(255,255,255,0.4);">CAMC Worldwide</div></div>
      </div>
    </div>
    <nav class="admin-nav">
      <a href="dashboard.php" class="admin-nav-item">📊 Dashboard</a>
      <a href="sermons.php" class="admin-nav-item">🎙 Sermons</a>
      <a href="events.php" class="admin-nav-item">📅 Events</a>
      <a href="gallery.php" class="admin-nav-item active">🖼 Gallery</a>
      <a href="branches.php" class="admin-nav-item">⛪ Branches</a>
      <a href="users.php" class="admin-nav-item">👥 Users</a>
      <div style="border-top:1px solid rgba(201,168,76,0.15); margin:1rem 0;"></div>
      <a href="../../index.php" class="admin-nav-item" target="_blank">🌐 View Website</a>
      <a href="../logout.php" class="admin-nav-item" style="color:#ef4444;">🚪 Logout</a>
    </nav>
  </div>
  <div class="admin-main">
    <div class="admin-topbar">
      <h2>Gallery Management</h2>
      <span style="font-size:12px; color:rgba(255,255,255,0.4);"><?php echo count($gallery); ?> photos</span>
    </div>

    <?php echo $msg; ?>
    <?php if (isset($_GET['deleted'])): ?>
    <div style="background:rgba(239,68,68,0.15); border:1px solid #ef4444; color:#ef4444; padding:0.75rem; border-radius:6px; margin-bottom:1rem;">🗑 Photo deleted.</div>
    <?php endif; ?>

    <!-- Upload Form -->
    <div style="background:var(--navy-light); border-radius:10px; padding:2rem; margin-bottom:2rem; border:1px solid rgba(201,168,76,0.15);">
      <div style="font-family:'Cinzel',serif; color:var(--gold); font-size:13px; letter-spacing:2px; text-transform:uppercase; margin-bottom:1.5rem;">Upload New Photos</div>
      <form method="POST" enctype="multipart/form-data">
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
          <div class="form-group">
            <label>Event Name</label>
            <input type="text" name="event" placeholder="e.g. January Salvation Vigil 2026">
          </div>
          <div class="form-group">
            <label>Branch</label>
            <select name="branch">
              <option>Abule-Egba HQ</option>
              <option>Idi-Oro Mushin</option>
              <option>Ibadan Central</option>
              <option>All Branches</option>
            </select>
          </div>
          <div class="form-group">
            <label>Caption / Description</label>
            <input type="text" name="caption" placeholder="Short description of photos">
          </div>
          <div class="form-group">
            <label>Event Date</label>
            <input type="date" name="date" value="<?php echo date('Y-m-d'); ?>">
          </div>
        </div>
        <label class="upload-zone" for="photoUpload" onclick="">
          <input type="file" id="photoUpload" name="photo[]" multiple accept="image/*" onchange="previewFiles(this)">
          <div class="icon">📷</div>
          <p>Click to select photos or drag &amp; drop here</p>
          <p class="sub">JPEG, PNG, WebP — Multiple files allowed — Max 10MB each</p>
          <div id="fileCount" style="color:var(--gold); font-size:13px; font-weight:700; margin-top:0.5rem;"></div>
        </label>
        <div id="previewGrid" style="display:grid; grid-template-columns:repeat(auto-fill,minmax(100px,1fr)); gap:8px; margin-top:1rem;"></div>
        <button type="submit" class="btn btn-gold" style="margin-top:1rem;">Upload Photos</button>
      </form>
    </div>

    <!-- Gallery Grid -->
    <div style="font-family:'Cinzel',serif; color:var(--gold); font-size:13px; letter-spacing:2px; text-transform:uppercase; margin-bottom:1rem;">Current Gallery (<?php echo count($gallery); ?> Photos)</div>
    <div class="photo-grid">
      <?php foreach(array_reverse($gallery) as $p): 
        $src = strpos($p['file'], 'assets/') === 0 ? '../../' . $p['file'] : $p['file'];
      ?>
      <div class="photo-item">
        <img src="<?php echo htmlspecialchars($src); ?>" alt="<?php echo htmlspecialchars($p['caption']); ?>" loading="lazy">
        <div class="photo-caption">
          <strong><?php echo htmlspecialchars($p['event'] ?? ''); ?></strong>
          <?php echo htmlspecialchars($p['caption']); ?>
        </div>
        <div class="photo-actions">
          <a href="gallery.php?delete=<?php echo $p['id']; ?>" onclick="return confirm('Delete this photo?')" class="btn btn-gold" style="font-size:11px; padding:8px 16px;">🗑 Delete</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<script>
function previewFiles(input) {
  const grid = document.getElementById('previewGrid');
  const count = document.getElementById('fileCount');
  grid.innerHTML = '';
  count.textContent = input.files.length + ' file(s) selected';
  Array.from(input.files).forEach(f => {
    const reader = new FileReader();
    reader.onload = e => {
      const div = document.createElement('div');
      div.style.cssText = 'aspect-ratio:1; overflow:hidden; border-radius:6px; border:2px solid rgba(201,168,76,0.3)';
      div.innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover;">';
      grid.appendChild(div);
    };
    reader.readAsDataURL(f);
  });
}
</script>
</body></html>
