<?php
session_start();
if (!isset($_SESSION['admin_role']) || $_SESSION['admin_role'] !== 'branch') { header('Location: ../login.php'); exit; }
$branch = $_SESSION['admin_branch'] ?? 'My Branch';
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Branch Info - CAMC Admin</title>
<link rel="stylesheet" href="../../assets/css/style.css">
<style>body{background:#0a1628;margin:0;}</style>
</head><body class="admin-body"><div class="admin-layout">
  <div class="admin-sidebar">
    <div class="admin-sidebar-logo"><div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;font-weight:700;">⛪ Branch Admin</div><div style="font-size:11px;color:rgba(255,255,255,0.4);"><?php echo htmlspecialchars($branch); ?></div></div>
    <nav class="admin-nav">
      <a href="dashboard.php" class="admin-nav-item">📊 Dashboard</a>
      <a href="sermons.php" class="admin-nav-item">🎙 Sermons</a>
      <a href="events.php" class="admin-nav-item">📅 Events</a>
      <a href="gallery.php" class="admin-nav-item">🖼 Gallery</a>
      <a href="settings.php" class="admin-nav-item active">⚙ Branch Info</a>
      <div style="border-top:1px solid rgba(201,168,76,0.15);margin:1rem 0;"></div>
      <a href="../../index.php" class="admin-nav-item" target="_blank">🌐 View Website</a>
      <a href="../logout.php" class="admin-nav-item" style="color:#ef4444;">🚪 Logout</a>
    </nav>
  </div>
  <div class="admin-main">
    <div class="admin-topbar"><h2>Branch Information</h2></div>
    <div style="background:var(--navy-light);border-radius:10px;padding:2rem;border:1px solid rgba(201,168,76,0.15);">
      <div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;letter-spacing:2px;margin-bottom:1.5rem;">BRANCH DETAILS — <?php echo htmlspecialchars($branch); ?></div>
      <div class="form-group"><label>Branch Name</label><input type="text" value="<?php echo htmlspecialchars($branch); ?>"></div>
      <div class="form-group"><label>Branch Pastor</label><input type="text" placeholder="Pastor's full name"></div>
      <div class="form-group"><label>Address</label><input type="text" placeholder="Branch address"></div>
      <div class="form-group"><label>Phone</label><input type="tel" placeholder="Branch phone"></div>
      <p style="color:rgba(255,255,255,0.4);font-size:12px;">Contact the Super Admin to update branch information on the public website.</p>
    </div>
  </div>
</div></body></html>
