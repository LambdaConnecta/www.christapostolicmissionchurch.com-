<?php
session_start();
if (!isset($_SESSION['admin_role']) || $_SESSION['admin_role'] !== 'super') { header('Location: ../login.php'); exit; }
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Settings - CAMC Admin</title>
<link rel="stylesheet" href="../../assets/css/style.css">
<style>body{background:#0a1628;margin:0;}</style>
</head><body class="admin-body"><div class="admin-layout">
  <div class="admin-sidebar">
    <div class="admin-sidebar-logo"><div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;font-weight:700;">⛪ Super Admin</div></div>
    <nav class="admin-nav">
      <a href="dashboard.php" class="admin-nav-item">📊 Dashboard</a>
      <a href="sermons.php" class="admin-nav-item">🎙 Sermons</a>
      <a href="events.php" class="admin-nav-item">📅 Events</a>
      <a href="gallery.php" class="admin-nav-item">🖼 Gallery</a>
      <a href="branches.php" class="admin-nav-item">⛪ Branches</a>
      <a href="users.php" class="admin-nav-item">👥 Users</a>
      <a href="settings.php" class="admin-nav-item active">⚙ Settings</a>
      <div style="border-top:1px solid rgba(201,168,76,0.15);margin:1rem 0;"></div>
      <a href="../../index.php" class="admin-nav-item" target="_blank">🌐 View Website</a>
      <a href="../logout.php" class="admin-nav-item" style="color:#ef4444;">🚪 Logout</a>
    </nav>
  </div>
  <div class="admin-main">
    <div class="admin-topbar"><h2>Settings</h2></div>
    <div style="background:var(--navy-light);border-radius:10px;padding:2rem;border:1px solid rgba(201,168,76,0.15);">
      <div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;letter-spacing:2px;margin-bottom:1.5rem;">WEBSITE SETTINGS</div>
      <div class="form-group"><label>Church Name</label><input type="text" value="Christ Apostolic Mission Church"></div>
      <div class="form-group"><label>Tagline</label><input type="text" value="Our Year of New Beginning — Rev 21:5"></div>
      <div class="form-group"><label>Main Phone</label><input type="tel" value="+2347048700005"></div>
      <div class="form-group"><label>Address</label><input type="text" value="1/5 CAMC Salvation Street, Abule-Egba, Lagos"></div>
      <div class="form-group"><label>Contact Email</label><input type="email" value="info@christapostolicmissionchurch.com" placeholder="info@christapostolicmissionchurch.com"></div>
      <p style="color:rgba(255,255,255,0.4);font-size:12px;margin-bottom:1rem;">Note: To persist settings, add a database or edit the PHP files directly. This form is for UI reference.</p>
      <button class="btn btn-gold">Save Settings</button>
    </div>
  </div>
</div></body></html>
