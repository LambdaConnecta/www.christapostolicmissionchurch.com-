<?php
session_start();
if (!isset($_SESSION['admin_role']) || $_SESSION['admin_role'] !== 'super') {
    header('Location: ../login.php'); exit;
}
$name = $_SESSION['admin_name'];
$currentPage = basename($_SERVER['PHP_SELF']);

// Data file helpers
$dataDir = '../../includes/data/';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);

function readData($file, $dataDir) {
    $path = $dataDir . $file;
    if (file_exists($path)) return json_decode(file_get_contents($path), true) ?: [];
    return [];
}

$sermons = readData('sermons.json', $dataDir);
$events = readData('events.json', $dataDir);
$branches = readData('branches.json', $dataDir);
$gallery = readData('gallery.json', $dataDir);

// Default branches
if (empty($branches)) {
    $branches = [
        ['id'=>1,'name'=>'Abule-Egba HQ','address'=>'1/5 CAMC Salvation Street','city'=>'Lagos','status'=>'active'],
        ['id'=>2,'name'=>'Idi-Oro Mushin','address'=>'6 Iyasuna Street, Idi-Oro','city'=>'Lagos','status'=>'active'],
        ['id'=>3,'name'=>'Ibadan Central','address'=>'Ibadan, Oyo State','city'=>'Ibadan','status'=>'active'],
    ];
    file_put_contents($dataDir . 'branches.json', json_encode($branches));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Super Admin Dashboard - CAMC</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
  <style>
    body { background: #0a1628; margin: 0; }
    .welcome-banner {
      background: linear-gradient(135deg, rgba(201,168,76,0.15), rgba(139,26,26,0.1));
      border: 1px solid rgba(201,168,76,0.2);
      border-radius: 10px;
      padding: 1.5rem 2rem;
      margin-bottom: 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
    }
    .welcome-banner h2 { font-family: 'Cinzel', serif; color: var(--white); font-size: 1.2rem; }
    .welcome-banner p { color: rgba(255,255,255,0.5); font-size: 13px; }
    .section-header { 
      font-family: 'Cinzel', serif; 
      color: var(--gold); 
      font-size: 13px; 
      letter-spacing: 2px;
      text-transform: uppercase;
      margin-bottom: 1rem;
      padding-bottom: 0.5rem;
      border-bottom: 1px solid rgba(201,168,76,0.2);
    }
    .action-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
      gap: 1rem;
      margin-bottom: 2rem;
    }
    .action-btn {
      background: var(--navy-light);
      border: 1px solid rgba(201,168,76,0.2);
      border-radius: 8px;
      padding: 1.2rem;
      text-align: center;
      cursor: pointer;
      text-decoration: none;
      display: block;
      transition: all 0.2s;
    }
    .action-btn:hover { border-color: var(--gold); background: rgba(201,168,76,0.08); }
    .action-btn .icon { font-size: 1.8rem; margin-bottom: 0.5rem; }
    .action-btn .label { font-size: 12px; font-weight: 700; letter-spacing: 1px; color: rgba(255,255,255,0.7); text-transform: uppercase; }
  </style>
</head>
<body class="admin-body">
<div class="admin-layout">
  <!-- SIDEBAR -->
  <div class="admin-sidebar">
    <div class="admin-sidebar-logo">
      <div style="display:flex; align-items:center; gap:10px;">
        <div style="width:42px; height:42px; border-radius:50%; overflow:hidden; border:2px solid var(--gold); background:#fff; flex-shrink:0;">
          <img src="../../assets/images/camc-logo.jpg" alt="CAMC" style="width:100%;height:100%;object-fit:cover;">
        </div>
        <div>
          <div style="font-family:'Cinzel',serif; color:var(--gold); font-size:13px; font-weight:700;">Super Admin</div>
          <div style="font-size:11px; color:rgba(255,255,255,0.4);">CAMC Worldwide</div>
        </div>
      </div>
    </div>
    <nav class="admin-nav">
      <a href="dashboard.php" class="admin-nav-item active">📊 Dashboard</a>
      <a href="sermons.php" class="admin-nav-item">🎙 Sermons</a>
      <a href="events.php" class="admin-nav-item">📅 Events</a>
      <a href="gallery.php" class="admin-nav-item">🖼 Gallery</a>
      <a href="branches.php" class="admin-nav-item">⛪ Branches</a>
      <a href="users.php" class="admin-nav-item">👥 Users</a>
      <a href="settings.php" class="admin-nav-item">⚙ Settings</a>
      <div style="border-top:1px solid rgba(201,168,76,0.15); margin:1rem 0;"></div>
      <a href="../../index.php" class="admin-nav-item" target="_blank">🌐 View Website</a>
      <a href="../logout.php" class="admin-nav-item" style="color:#ef4444;">🚪 Logout</a>
    </nav>
  </div>

  <!-- MAIN -->
  <div class="admin-main">
    <div class="admin-topbar">
      <div>
        <h2>Super Admin Dashboard</h2>
        <p style="font-size:12px; color:rgba(255,255,255,0.4); margin-top:2px;">CAMC Worldwide Management</p>
      </div>
      <div style="display:flex; align-items:center; gap:12px;">
        <span style="font-size:12px; color:rgba(255,255,255,0.4);">👤 <?php echo htmlspecialchars($name); ?></span>
        <a href="../logout.php" class="btn btn-gold" style="font-size:11px; padding:8px 16px;">Logout</a>
      </div>
    </div>

    <!-- Welcome Banner -->
    <div class="welcome-banner">
      <div>
        <h2>Welcome, <?php echo htmlspecialchars($name); ?>!</h2>
        <p>Managing CAMC Worldwide · <?php echo date('l, F j, Y'); ?></p>
      </div>
      <div style="font-size:2rem;">⛪</div>
    </div>

    <!-- Stats Cards -->
    <div class="admin-cards">
      <div class="admin-card">
        <div class="card-num"><?php echo count($branches); ?></div>
        <div class="card-label">Active Branches</div>
      </div>
      <div class="admin-card">
        <div class="card-num"><?php echo count($sermons); ?></div>
        <div class="card-label">Sermons</div>
      </div>
      <div class="admin-card">
        <div class="card-num"><?php echo count($events); ?></div>
        <div class="card-label">Events</div>
      </div>
      <div class="admin-card">
        <div class="card-num"><?php echo count($gallery); ?></div>
        <div class="card-label">Gallery Items</div>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="section-header">Quick Actions</div>
    <div class="action-grid">
      <a href="gallery.php" class="action-btn"><div class="icon">🖼</div><div class="label">Upload Photos</div></a>
      <a href="sermons.php" class="action-btn"><div class="icon">🎙</div><div class="label">Add Sermon</div></a>
      <a href="events.php" class="action-btn"><div class="icon">📅</div><div class="label">Add Event</div></a>
      <a href="branches.php" class="action-btn"><div class="icon">⛪</div><div class="label">Manage Branches</div></a>
      <a href="users.php" class="action-btn"><div class="icon">👥</div><div class="label">Manage Users</div></a>
    </div>

    <!-- Branches Table -->
    <div class="section-header">Branches Overview</div>
    <table class="admin-table" style="margin-bottom:2rem;">
      <thead>
        <tr><th>Branch Name</th><th>City</th><th>Address</th><th>Status</th><th>Action</th></tr>
      </thead>
      <tbody>
        <?php foreach($branches as $b): ?>
        <tr>
          <td style="font-weight:700; color:var(--white);">⛪ <?php echo htmlspecialchars($b['name']); ?></td>
          <td><?php echo htmlspecialchars($b['city']); ?></td>
          <td><?php echo htmlspecialchars($b['address']); ?></td>
          <td><span class="badge badge-green">Active</span></td>
          <td><a href="branches.php" style="color:var(--gold); font-size:12px; font-weight:700;">Edit</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

  </div>
</div>
</body>
</html>
