<?php
session_start();
if (!isset($_SESSION['admin_role']) || $_SESSION['admin_role'] !== 'super') { header('Location: ../login.php'); exit; }

$dataDir = '../../includes/data/';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
$eventsFile = $dataDir . 'events.json';
$events = file_exists($eventsFile) ? json_decode(file_get_contents($eventsFile), true) : [];

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $events[] = [
        'id' => time(),
        'title' => htmlspecialchars($_POST['title'] ?? ''),
        'date' => $_POST['date'] ?? date('Y-m-d'),
        'time' => htmlspecialchars($_POST['time'] ?? ''),
        'location' => htmlspecialchars($_POST['location'] ?? ''),
        'description' => htmlspecialchars($_POST['description'] ?? ''),
        'branch' => htmlspecialchars($_POST['branch'] ?? 'All Branches'),
    ];
    file_put_contents($eventsFile, json_encode($events));
    $msg = '<div style="background:rgba(34,197,94,0.15);border:1px solid #22c55e;color:#22c55e;padding:.75rem;border-radius:6px;margin-bottom:1rem;">✅ Event added!</div>';
}
if (isset($_GET['delete'])) {
    $events = array_values(array_filter($events, fn($e) => $e['id'] != (int)$_GET['delete']));
    file_put_contents($eventsFile, json_encode($events));
    header('Location: events.php'); exit;
}
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Events - CAMC Admin</title>
<link rel="stylesheet" href="../../assets/css/style.css">
<style>body{background:#0a1628;margin:0;}</style>
</head><body class="admin-body"><div class="admin-layout">
  <div class="admin-sidebar">
    <div class="admin-sidebar-logo"><div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;font-weight:700;">⛪ Super Admin</div></div>
    <nav class="admin-nav">
      <a href="dashboard.php" class="admin-nav-item">📊 Dashboard</a>
      <a href="sermons.php" class="admin-nav-item">🎙 Sermons</a>
      <a href="events.php" class="admin-nav-item active">📅 Events</a>
      <a href="gallery.php" class="admin-nav-item">🖼 Gallery</a>
      <a href="branches.php" class="admin-nav-item">⛪ Branches</a>
      <a href="users.php" class="admin-nav-item">👥 Users</a>
      <div style="border-top:1px solid rgba(201,168,76,0.15);margin:1rem 0;"></div>
      <a href="../../index.php" class="admin-nav-item" target="_blank">🌐 View Website</a>
      <a href="../logout.php" class="admin-nav-item" style="color:#ef4444;">🚪 Logout</a>
    </nav>
  </div>
  <div class="admin-main">
    <div class="admin-topbar"><h2>Events</h2></div>
    <?php echo $msg; ?>
    <div style="background:var(--navy-light);border-radius:10px;padding:2rem;margin-bottom:2rem;border:1px solid rgba(201,168,76,0.15);">
      <div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;letter-spacing:2px;margin-bottom:1.5rem;">ADD EVENT</div>
      <form method="POST">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
          <div class="form-group"><label>Event Title</label><input type="text" name="title" required placeholder="Event name"></div>
          <div class="form-group"><label>Date</label><input type="date" name="date" value="<?php echo date('Y-m-d'); ?>"></div>
          <div class="form-group"><label>Time</label><input type="text" name="time" placeholder="e.g. 7:00pm – Dawn"></div>
          <div class="form-group"><label>Location</label><input type="text" name="location" placeholder="Venue / address"></div>
          <div class="form-group"><label>Branch</label><select name="branch"><option>All Branches</option><option>Abule-Egba HQ</option><option>Idi-Oro Mushin</option><option>Ibadan Central</option></select></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description" placeholder="Event details"></textarea></div>
        <button type="submit" class="btn btn-gold">Add Event</button>
      </form>
    </div>
    <?php if (!empty($events)): ?>
    <table class="admin-table">
      <thead><tr><th>Title</th><th>Date</th><th>Location</th><th>Branch</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach(array_reverse($events) as $e): ?>
        <tr>
          <td style="font-weight:700;color:var(--white);"><?php echo htmlspecialchars($e['title']); ?></td>
          <td><?php echo $e['date']; ?><br><span style="font-size:11px;color:rgba(255,255,255,0.4);"><?php echo htmlspecialchars($e['time']); ?></span></td>
          <td><?php echo htmlspecialchars($e['location']); ?></td>
          <td><span class="badge badge-yellow"><?php echo htmlspecialchars($e['branch']); ?></span></td>
          <td><a href="events.php?delete=<?php echo $e['id']; ?>" onclick="return confirm('Delete?')" style="color:#ef4444;font-size:12px;font-weight:700;">Delete</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div style="text-align:center;padding:3rem;color:rgba(255,255,255,0.3);">No events yet.</div>
    <?php endif; ?>
  </div>
</div></body></html>
