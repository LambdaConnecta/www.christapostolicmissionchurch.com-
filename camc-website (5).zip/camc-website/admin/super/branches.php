<?php
session_start();
if (!isset($_SESSION['admin_role']) || $_SESSION['admin_role'] !== 'super') { header('Location: ../login.php'); exit; }

$dataDir = '../../includes/data/';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
$branchFile = $dataDir . 'branches.json';
$branches = file_exists($branchFile) ? json_decode(file_get_contents($branchFile), true) : [];

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $branches[] = [
        'id' => time(),
        'name' => htmlspecialchars($_POST['name'] ?? ''),
        'address' => htmlspecialchars($_POST['address'] ?? ''),
        'city' => htmlspecialchars($_POST['city'] ?? ''),
        'phone' => htmlspecialchars($_POST['phone'] ?? ''),
        'pastor' => htmlspecialchars($_POST['pastor'] ?? ''),
        'status' => 'active',
    ];
    file_put_contents($branchFile, json_encode($branches));
    $msg = '<div style="background:rgba(34,197,94,0.15);border:1px solid #22c55e;color:#22c55e;padding:.75rem;border-radius:6px;margin-bottom:1rem;">✅ Branch added!</div>';
}
if (isset($_GET['delete'])) {
    $branches = array_values(array_filter($branches, fn($b) => $b['id'] != (int)$_GET['delete']));
    file_put_contents($branchFile, json_encode($branches));
    header('Location: branches.php'); exit;
}
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Branches - CAMC Admin</title>
<link rel="stylesheet" href="../../assets/css/style.css">
<style>body{background:#0a1628;margin:0;}</style>
</head><body class="admin-body"><div class="admin-layout">
  <div class="admin-sidebar">
    <div class="admin-sidebar-logo"><div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;font-weight:700;">⛪ Super Admin</div></div>
    <nav class="admin-nav">
      <a href="dashboard.php" class="admin-nav-item">📊 Dashboard</a>
      <a href="sermons.php" class="admin-nav-item">🎙 Sermons</a>
      <a href="events.php" class="admin-nav-item">📅 Events</a>
      <a href="gallery.php" class="admin-nav-item">🖼 Gallery</a>
      <a href="branches.php" class="admin-nav-item active">⛪ Branches</a>
      <a href="users.php" class="admin-nav-item">👥 Users</a>
      <div style="border-top:1px solid rgba(201,168,76,0.15);margin:1rem 0;"></div>
      <a href="../../index.php" class="admin-nav-item" target="_blank">🌐 View Website</a>
      <a href="../logout.php" class="admin-nav-item" style="color:#ef4444;">🚪 Logout</a>
    </nav>
  </div>
  <div class="admin-main">
    <div class="admin-topbar"><h2>Branches</h2><span style="font-size:12px;color:rgba(255,255,255,0.4);"><?php echo count($branches); ?> branches</span></div>
    <?php echo $msg; ?>
    <div style="background:var(--navy-light);border-radius:10px;padding:2rem;margin-bottom:2rem;border:1px solid rgba(201,168,76,0.15);">
      <div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;letter-spacing:2px;margin-bottom:1.5rem;">ADD BRANCH</div>
      <form method="POST">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
          <div class="form-group"><label>Branch Name</label><input type="text" name="name" required placeholder="e.g. Ikeja Branch"></div>
          <div class="form-group"><label>City / State</label><input type="text" name="city" required placeholder="e.g. Lagos"></div>
          <div class="form-group"><label>Full Address</label><input type="text" name="address" placeholder="Street address"></div>
          <div class="form-group"><label>Phone</label><input type="tel" name="phone" placeholder="Branch phone number"></div>
          <div class="form-group"><label>Branch Pastor</label><input type="text" name="pastor" placeholder="Pastor's name"></div>
        </div>
        <button type="submit" class="btn btn-gold">Add Branch</button>
      </form>
    </div>
    <table class="admin-table">
      <thead><tr><th>Branch</th><th>City</th><th>Pastor</th><th>Phone</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach($branches as $b): ?>
        <tr>
          <td style="font-weight:700;color:var(--white);">⛪ <?php echo htmlspecialchars($b['name']); ?><br><span style="font-size:11px;color:rgba(255,255,255,0.4);"><?php echo htmlspecialchars($b['address'] ?? ''); ?></span></td>
          <td><?php echo htmlspecialchars($b['city']); ?></td>
          <td><?php echo htmlspecialchars($b['pastor'] ?? '—'); ?></td>
          <td><?php echo htmlspecialchars($b['phone'] ?? '—'); ?></td>
          <td><span class="badge badge-green">Active</span></td>
          <td><?php if(isset($b['id']) && $b['id'] > 3): ?><a href="branches.php?delete=<?php echo $b['id']; ?>" onclick="return confirm('Delete?')" style="color:#ef4444;font-size:12px;font-weight:700;">Delete</a><?php else: ?><span style="color:rgba(255,255,255,0.2);font-size:12px;">Default</span><?php endif; ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div></body></html>
