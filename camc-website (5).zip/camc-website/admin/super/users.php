<?php
session_start();
if (!isset($_SESSION['admin_role']) || $_SESSION['admin_role'] !== 'super') { header('Location: ../login.php'); exit; }
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Users - CAMC Admin</title>
<link rel="stylesheet" href="../../assets/css/style.css">
<style>body{background:#0a1628;margin:0;}</style>
</head><body class="admin-body"><div class="admin-layout">
  <div class="admin-sidebar">
    <div class="admin-sidebar-logo"><div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;font-weight:700;">⛪ Super Admin</div></div>
    <nav class="admin-nav">
      <a href="dashboard.php" class="admin-nav-item">📊 Dashboard</a>
      <a href="sermons.php" class="admin-nav-item">🎙 Sermons</a>
      <a href="events.php" class="admin-nav-item">📅 Events</a>
      <a href="gallery.php" class="admin-nav-item">🖼 Gallery</a>
      <a href="branches.php" class="admin-nav-item">⛪ Branches</a>
      <a href="users.php" class="admin-nav-item active">👥 Users</a>
      <div style="border-top:1px solid rgba(201,168,76,0.15);margin:1rem 0;"></div>
      <a href="../../index.php" class="admin-nav-item" target="_blank">🌐 View Website</a>
      <a href="../logout.php" class="admin-nav-item" style="color:#ef4444;">🚪 Logout</a>
    </nav>
  </div>
  <div class="admin-main">
    <div class="admin-topbar"><h2>Users & Access</h2></div>
    
    <div style="background:rgba(201,168,76,0.08);border:1px solid rgba(201,168,76,0.2);border-radius:10px;padding:1.5rem;margin-bottom:2rem;">
      <p style="color:var(--gold);font-weight:700;margin-bottom:0.5rem;">⚠ Security Notice</p>
      <p style="color:rgba(255,255,255,0.6);font-size:13px;">User credentials are stored in <code style="color:var(--gold);">admin/login.php</code>. For production, update the <code style="color:var(--gold);">$users</code> array with strong passwords, or integrate a MySQL database for full user management.</p>
    </div>

    <table class="admin-table">
      <thead><tr><th>Name</th><th>Role</th><th>Branch</th><th>Password</th></tr></thead>
      <tbody>
        <tr>
          <td style="font-weight:700;color:var(--white);">Super Admin</td>
          <td><span class="badge badge-red">Super Admin</span></td>
          <td>All Branches</td>
          <td style="color:rgba(255,255,255,0.3); letter-spacing:3px;">••••••••••••</td>
        </tr>
        <tr>
          <td style="font-weight:700;color:var(--white);">Abule-Egba Branch Admin</td>
          <td><span class="badge badge-yellow">Branch Admin</span></td>
          <td>Abule-Egba</td>
          <td style="color:rgba(255,255,255,0.3); letter-spacing:3px;">••••••••••••</td>
        </tr>
        <tr>
          <td style="font-weight:700;color:var(--white);">Mushin Branch Admin</td>
          <td><span class="badge badge-yellow">Branch Admin</span></td>
          <td>Idi-Oro Mushin</td>
          <td style="color:rgba(255,255,255,0.3); letter-spacing:3px;">••••••••••••</td>
        </tr>
        <tr>
          <td style="font-weight:700;color:var(--white);">Ibadan Branch Admin</td>
          <td><span class="badge badge-yellow">Branch Admin</span></td>
          <td>Ibadan Central</td>
          <td style="color:rgba(255,255,255,0.3); letter-spacing:3px;">••••••••••••</td>
        </tr>
      </tbody>
    </table>
    
    <div style="margin-top:2rem;background:var(--navy-light);border-radius:10px;padding:2rem;border:1px solid rgba(201,168,76,0.15);">
      <div style="font-family:'Cinzel',serif;color:var(--gold);font-size:13px;letter-spacing:2px;margin-bottom:1rem;">NEED TO ADD OR CHANGE ACCESS?</div>
      <p style="color:rgba(255,255,255,0.6);font-size:13px;line-height:1.8;">
        To add a new branch admin or update login credentials, contact the website administrator: <strong style="color:var(--gold);">Dr. Andrew Ebhoma</strong>. Credentials are managed privately and are never displayed publicly.
      </p>
    </div>
  </div>
</div></body></html>
