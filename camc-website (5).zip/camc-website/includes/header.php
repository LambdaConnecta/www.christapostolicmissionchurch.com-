<?php
$page = basename($_SERVER['PHP_SELF'], '.php');
$base = '';
if (strpos($_SERVER['PHP_SELF'], '/pages/') !== false || strpos($_SERVER['PHP_SELF'], '/admin/') !== false) {
    $base = '../';
}
if (strpos($_SERVER['PHP_SELF'], '/admin/branch/') !== false || strpos($_SERVER['PHP_SELF'], '/admin/super/') !== false) {
    $base = '../../';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo isset($pageTitle) ? $pageTitle . ' | CAMC' : 'Christ Apostolic Mission Church'; ?></title>
  <meta name="description" content="<?php echo isset($pageDesc) ? $pageDesc : 'Christ Apostolic Mission Church - A Vibrant Pentecostal Church in Nigeria'; ?>">
  <link rel="stylesheet" href="<?php echo $base; ?>assets/css/style.css">
  <link rel="icon" href="<?php echo $base; ?>assets/images/camc-logo-favicon.jpg" type="image/jpeg">
</head>
<body>

<nav>
  <div class="nav-inner">
    <a href="<?php echo $base; ?>index.php" class="nav-logo">
      <div class="nav-logo-circle">
        <img src="<?php echo $base; ?>assets/images/camc-logo-nav.jpg" alt="CAMC Logo" class="nav-logo-img">
      </div>
      <div class="nav-logo-text">
        <span class="main">CAMC</span>
        <span class="sub">Christ Apostolic Mission Church</span>
      </div>
    </a>

    <ul class="nav-links" id="navLinks">
      <li><a href="<?php echo $base; ?>index.php">Home</a></li>
      <li><a href="<?php echo $base; ?>pages/about.php">About</a></li>
      <li><a href="<?php echo $base; ?>pages/leadership.php">Leadership</a></li>
      <li><a href="<?php echo $base; ?>pages/sermons.php">Sermons</a></li>
      <li><a href="<?php echo $base; ?>pages/events.php">Events</a></li>
      <li><a href="<?php echo $base; ?>pages/gallery.php">Gallery</a></li>
      <li><a href="<?php echo $base; ?>pages/branches.php">Branches</a></li>
      <li><a href="<?php echo $base; ?>pages/contact.php">Contact</a></li>
      <li><a href="<?php echo $base; ?>admin/login.php" class="nav-cta">Admin</a></li>
    </ul>
    <button class="nav-toggle" onclick="document.getElementById('navLinks').classList.toggle('open')">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>
