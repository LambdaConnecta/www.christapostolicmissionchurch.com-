
<!-- LIGHTBOX -->
<div id="lightbox" class="lightbox">
  <button id="lb-close" class="lightbox-close">✕</button>
  <button id="lb-prev" class="lightbox-prev">&#8592;</button>
  <img id="lightbox-img" src="" alt="">
  <button id="lb-next" class="lightbox-next">&#8594;</button>
</div>

<footer>
  <!-- DESIGNER CREDIT BAND -->
  <div style="background:linear-gradient(90deg, var(--gold), var(--deep-gold)); padding:10px 2rem; text-align:center;">
    <p style="font-family:'Cinzel',serif; font-size:12px; letter-spacing:3px; color:var(--navy); font-weight:700; text-transform:uppercase; margin:0;">
      ✦ Website Designed &amp; Developed by Dr. Andrew Ebhoma ✦
    </p>
  </div>
  <div class="footer-grid">
    <div class="footer-brand">
      <a href="<?php echo $base; ?>index.php" style="display:flex; align-items:center; gap:14px; text-decoration:none; margin-bottom:1rem;">
        <div style="width:64px; height:64px; border-radius:50%; overflow:hidden; border:2px solid var(--gold); background:#fff; flex-shrink:0;">
          <img src="<?php echo $base; ?>assets/images/camc-logo.jpg" alt="CAMC Logo" style="width:100%;height:100%;object-fit:cover;">
        </div>
        <div class="nav-logo-text">
          <span class="main">CAMC</span>
          <span class="sub">Christ Apostolic Mission Church</span>
        </div>
      </a>
      <p style="color:rgba(255,255,255,0.5); font-size:13px; margin-top: 1rem; line-height: 1.8;">A vibrant Pentecostal church founded in 1952, committed to evangelism, miracles, and spiritual growth across Nigeria and beyond.</p>
      <p style="margin-top:1rem; color: rgba(255,255,255,0.35); font-size:12px;">
        ⛪ Est. December 13, 1952 · Lagos, Nigeria
      </p>
    </div>
    <div class="footer-col">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="<?php echo $base; ?>index.php">Home</a></li>
        <li><a href="<?php echo $base; ?>pages/about.php">About CAMC</a></li>
        <li><a href="<?php echo $base; ?>pages/leadership.php">Leadership</a></li>
        <li><a href="<?php echo $base; ?>pages/sermons.php">Sermons</a></li>
        <li><a href="<?php echo $base; ?>pages/gallery.php">Gallery</a></li>
        <li><a href="<?php echo $base; ?>pages/branches.php">Branches</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Programmes</h4>
      <ul>
        <li><a href="#">Sunday Service 7:00am</a></li>
        <li><a href="#">Sunday School 9:00am</a></li>
        <li><a href="#">Bible Studies Tue 6pm</a></li>
        <li><a href="#">Miracle Hour Wed 9am</a></li>
        <li><a href="#">Faith Clinic Fri 9am</a></li>
        <li><a href="#">Salvation Night (1st Fri)</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Contact</h4>
      <ul>
        <li><a href="#">1/5 CAMC Salvation Street</a></li>
        <li><a href="#">Abule-Egba, Lagos State</a></li>
        <li><a href="tel:+2347048700005">📞 +2347048700005</a></li>
        <li><a href="mailto:info@christapostolicmissionchurch.com">✉ info@christapostolicmissionchurch.com</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom" style="flex-direction:column; gap:0.75rem; text-align:center; padding:2rem 0;">
    <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:1rem; width:100%;">
      <span>© <?php echo date('Y'); ?> Christ Apostolic Mission Church (CAMC). All Rights Reserved.</span>
      <span>Founded by Apostle John Ajayi Agbona · 1952</span>
    </div>
    <div style="width:100%; border-top:1px solid rgba(201,168,76,0.15); padding-top:1.2rem; margin-top:0.5rem;">
      <p style="color:rgba(255,255,255,0.35); font-size:12px; letter-spacing:1px;">
        Website Designed &amp; Developed by
        <strong style="color:var(--gold); font-size:13px; letter-spacing:2px;"> Dr. Andrew Ebhoma</strong>
        &nbsp;·&nbsp; All Rights Reserved
      </p>
    </div>
  </div>
</footer>

<script src="<?php echo $base; ?>assets/js/main.js"></script>
</body>
</html>
