<?php
$pageTitle = 'Home - A New Beginning 2026';
$pageDesc = 'Christ Apostolic Mission Church - Year of New Beginning. Join us every Sunday at Abule-Egba, Lagos.';
$base = '';
include 'includes/header.php';
?>

<!-- HERO -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-particles"></div>
  <div class="hero-content">
    <div class="hero-badge">✦ 2026 · Year Theme ✦</div>
    <h1 class="hero-title">Our Year of<br><span class="accent">New Beginning</span></h1>
    <p class="hero-subtitle">Walking in the covenant promises of God</p>
    <p class="hero-verse">Revelation 21:5 — "Behold, I make all things new"</p>
    <div class="hero-btns">
      <a href="pages/sermons.php" class="btn btn-gold">Watch Sermons</a>
      <a href="pages/about.php" class="btn btn-outline">Our Story</a>
    </div>
  </div>
  <div class="hero-scroll">Scroll</div>
</section>

<!-- TICKER -->
<div class="ticker">
  <div class="ticker-inner" id="tickerInner">
    <span>Sunday First Service — 7:00am–9:00am</span>
    <span>Sunday School — 9:00am–10:00am</span>
    <span>Second Service — 10:00am–1:00pm</span>
    <span>Tuesday Bible Studies — 6:00pm</span>
    <span>Wednesday Miracle Hour — 9:00am–12noon</span>
    <span>Thursday Good Women Society — 5:00pm–6:00pm</span>
    <span>Friday Faith Clinic — 9:00am–12noon</span>
    <span>First Friday — Salvation Night</span>
    <span>Last Day of Month — Prosperity Night</span>
    <span>First Sunday — Anointing Service</span>
    <!-- Duplicate for seamless loop -->
    <span>Sunday First Service — 7:00am–9:00am</span>
    <span>Sunday School — 9:00am–10:00am</span>
    <span>Second Service — 10:00am–1:00pm</span>
    <span>Tuesday Bible Studies — 6:00pm</span>
    <span>Wednesday Miracle Hour — 9:00am–12noon</span>
    <span>Friday Faith Clinic — 9:00am–12noon</span>
    <span>First Friday — Salvation Night</span>
    <span>Last Day of Month — Prosperity Night</span>
  </div>
</div>

<!-- WELCOME -->
<section class="welcome">
  <div class="section-inner">
    <div class="welcome-grid">
      <div>
        <p class="section-label">Welcome to CAMC</p>
        <h2 class="section-title">Founded on <span class="accent">Faith & Fire</span></h2>
        <div class="divider"></div>
        <p class="welcome-text">
          Christ Apostolic Mission Church (CAMC) is a Pentecostal denomination founded on December 13, 1952 by Apostle John Ajayi Agbona at Bar Beach, Lagos. Born out of divine obedience, the church has grown from 5 founding members to a vibrant congregation spanning multiple branches across Nigeria.
        </p>
        <p class="welcome-text">
          We are a church of signs, wonders, and miracles — committed to evangelism, prayer, and the transformation of lives through the power of the Holy Spirit.
        </p>
        <a href="pages/about.php" class="btn btn-gold" style="margin-top:0.5rem;">Read Our History</a>
      </div>
      <div class="welcome-img-grid">
        <img src="assets/images/DSC_1375.jpg" alt="Congregation in worship" loading="lazy">
        <img src="assets/images/DSC_1371.jpg" alt="Worship service" loading="lazy">
        <img src="assets/images/DSC_1393.jpg" alt="Praise and worship" loading="lazy">
      </div>
    </div>
  </div>
</section>

<!-- STATS -->
<div class="stats-section">
  <div class="stats-grid">
    <div class="stat-item">
      <div class="number"><span class="counter" data-target="72" data-suffix="+">0+</span></div>
      <div class="label">Years of Ministry</div>
    </div>
    <div class="stat-item">
      <div class="number"><span class="counter" data-target="20" data-suffix="+">0+</span></div>
      <div class="label">Branches Nationwide</div>
    </div>
    <div class="stat-item">
      <div class="number"><span class="counter" data-target="1952" data-suffix="">0</span></div>
      <div class="label">Year Founded</div>
    </div>
    <div class="stat-item">
      <div class="number"><span class="counter" data-target="1000" data-suffix="+">0+</span></div>
      <div class="label">Members &amp; Growing</div>
    </div>
  </div>
</div>

<!-- PROGRAMMES -->
<section class="programs">
  <div class="section-inner">
    <p class="section-label">Come Worship With Us</p>
    <h2 class="section-title">Weekly <span class="accent">Programmes</span></h2>
    <div class="divider"></div>
    <div class="programs-grid">
      <div class="program-card">
        <div class="program-card-icon">🙏</div>
        <h3>Sunday First Service</h3>
        <p>Start your Sunday with powerful worship and the Word of God.</p>
        <span class="time">Sunday · 7:00am – 9:00am</span>
      </div>
      <div class="program-card">
        <div class="program-card-icon">📖</div>
        <h3>Sunday School</h3>
        <p>Deep dive into Scripture with our structured Bible education program.</p>
        <span class="time">Sunday · 9:00am – 10:00am</span>
      </div>
      <div class="program-card">
        <div class="program-card-icon">⛪</div>
        <h3>Second Service</h3>
        <p>The main celebration service with full choir, orchestra and powerful preaching.</p>
        <span class="time">Sunday · 10:00am – 1:00pm</span>
      </div>
      <div class="program-card">
        <div class="program-card-icon">📚</div>
        <h3>Bible Studies</h3>
        <p>Mid-week grounding in the Word of God for spiritual growth.</p>
        <span class="time">Tuesday · 6:00pm</span>
      </div>
      <div class="program-card">
        <div class="program-card-icon">✨</div>
        <h3>Miracle Hour</h3>
        <p>A special service of prayers, faith declarations and miraculous testimonies.</p>
        <span class="time">Wednesday · 9:00am – 12noon</span>
      </div>
      <div class="program-card">
        <div class="program-card-icon">👑</div>
        <h3>Good Women Society</h3>
        <p>Empowering women in faith, family and community impact.</p>
        <span class="time">Thursday · 5:00pm – 6:00pm</span>
      </div>
      <div class="program-card">
        <div class="program-card-icon">🔥</div>
        <h3>Faith Clinic</h3>
        <p>A healing and deliverance service where miracles happen consistently.</p>
        <span class="time">Friday · 9:00am – 12noon</span>
      </div>
      <div class="program-card">
        <div class="program-card-icon">🌙</div>
        <h3>Salvation Night</h3>
        <p>Monthly night vigil of prayer and salvation altar calls.</p>
        <span class="time">1st Friday of Every Month</span>
      </div>
      <div class="program-card">
        <div class="program-card-icon">💰</div>
        <h3>Prosperity Night</h3>
        <p>End-of-month service celebrating God's covenant of abundance.</p>
        <span class="time">Last Day of Every Month</span>
      </div>
    </div>
  </div>
</section>

<!-- GALLERY PREVIEW -->
<section class="gallery-section">
  <div class="section-inner">
    <p class="section-label" style="color:var(--gold);">Our Events</p>
    <h2 class="section-title" style="color:var(--white);">January Salvation <span class="accent">Vigil 2026</span></h2>
    <div class="divider center"></div>
    <div class="gallery-grid">
      <?php
      $images = [
        ['DSC_1368.jpg', 'Woman kneeling in prayer'],
        ['DSC_1371.jpg', 'Congregation dancing'],
        ['DSC_1375.jpg', 'Hands raised in worship'],
        ['DSC_1381.jpg', 'Drum kit performance'],
        ['DSC_1384.jpg', 'Saxophonists leading praise'],
        ['DSC_1393.jpg', 'Leadership on stage'],
      ];
      foreach($images as $img) {
        echo '<div class="gallery-item">';
        echo '<img src="assets/images/' . $img[0] . '" alt="' . $img[1] . '" loading="lazy">';
        echo '<div class="gallery-overlay">' . $img[1] . '</div>';
        echo '</div>';
      }
      ?>
    </div>
    <div style="text-align:center; margin-top:2.5rem;">
      <a href="pages/gallery.php" class="btn btn-gold">View Full Gallery</a>
    </div>
  </div>
</section>

<!-- UPCOMING EVENTS -->
<section class="events-section">
  <div class="section-inner">
    <p class="section-label">What's Coming</p>
    <h2 class="section-title">Upcoming <span class="accent">Events</span></h2>
    <div class="divider"></div>
    <div class="event-item">
      <div class="event-date-box">
        <div class="day">07</div>
        <div class="month">Mar</div>
      </div>
      <div class="event-info">
        <h3>First Friday Salvation Night</h3>
        <div class="event-meta">📍 National Secretariat, Abule-Egba · Monthly</div>
        <p>An all-night prayer meeting and salvation service. Come expectant for miracles.</p>
      </div>
    </div>
    <div class="event-item">
      <div class="event-date-box">
        <div class="day">28</div>
        <div class="month">Mar</div>
      </div>
      <div class="event-info">
        <h3>Prosperity Night</h3>
        <div class="event-meta">📍 National Secretariat, Abule-Egba · Monthly</div>
        <p>End-of-month celebration of God's covenant of prosperity. Come with your testimonies.</p>
      </div>
    </div>
    <div class="event-item">
      <div class="event-date-box">
        <div class="day">23</div>
        <div class="month">Sep</div>
      </div>
      <div class="event-info">
        <h3>Annual Covenant of Prosperity Revival</h3>
        <div class="event-meta">📍 National Secretariat, Abule-Egba · Annual</div>
        <p>Our flagship annual revival commemorating God's covenant of prosperity established September 23, 2001.</p>
      </div>
    </div>
    <div style="text-align:center; margin-top:2.5rem;">
      <a href="pages/events.php" class="btn btn-gold">See All Events</a>
    </div>
  </div>
</section>

<!-- CONTACT STRIP -->
<section style="background:var(--navy); padding:60px 2rem;">
  <div class="section-inner" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:2rem;">
    <div>
      <h3 style="font-family:'Cinzel',serif; color:var(--white); font-size:1.5rem; margin-bottom:0.5rem;">Come Worship With Us</h3>
      <p style="color:rgba(255,255,255,0.6);">1/5 CAMC Salvation Street, Off Yisa Oladimeji Street,<br>U-Turn Bus-Stop, Abule-Egba, Lagos State</p>
    </div>
    <div style="display:flex; gap:1rem; flex-wrap:wrap;">
      <a href="tel:+2347048700005" class="btn btn-gold">📞 +2347048700005</a>
      <a href="https://wa.me/2347048700005?text=Hello%20CAMC!%20I%20have%20an%20enquiry." target="_blank" class="btn" style="background:#25D366; color:#fff;">💬 WhatsApp Us</a>
      <a href="pages/contact.php" class="btn btn-outline">Get Directions</a>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
