<?php
$pageTitle = 'Sermons - CAMC';
$base = '../';
include '../includes/header.php';

// Demo sermons
$sermons = [
  ['Our Year of New Beginning', 'Pastor John Babatunde, JP', 'Jan 26, 2026', 'Rev 21:5', 'The President ministers powerfully on what it means to step into a new beginning with God. A message of faith, hope and fresh expectations.', '#'],
  ['The Covenant of Prosperity', 'Pastor John Babatunde, JP', 'Jan 12, 2026', 'Gen 17:1-7', 'Understanding the eternal covenant that God established with His church in September 2001 and how to walk fully in its blessings.', '#'],
  ['Walking in Divine Obedience', 'Rev. Emmanuel Adeyemi', 'Jan 5, 2026', 'Deut 28:1', 'Drawing lessons from the life of Apostle Agbona whose radical obedience opened heavens over his life and ministry.', '#'],
  ['Miracle Is Your Portion', 'Evang. Sarah Okonkwo', 'Dec 29, 2025', 'Mk 16:17-18', 'A powerful message on why every believer is entitled to miracles as a covenant child of God.', '#'],
  ['Arise and Shine', 'Pastor John Babatunde, JP', 'Dec 22, 2025', 'Isa 60:1', 'Christmas message on how to shine in the midst of darkness — spiritually, professionally and in all areas of life.', '#'],
];
?>

<div class="page-hero">
  <div class="page-hero-content">
    <div class="breadcrumb">Home › Sermons</div>
    <h1>Sermons</h1>
    <p style="color:rgba(255,255,255,0.7); margin-top:0.75rem; font-family:'Playfair Display',serif; font-style:italic;">
      Nourish your spirit with the Word of God
    </p>
  </div>
</div>

<section style="background:var(--light-gray); padding:80px 2rem;">
  <div class="section-inner">
    <p class="section-label">Recent Messages</p>
    <h2 class="section-title">Latest <span class="accent">Sermons</span></h2>
    <div class="divider"></div>

    <?php foreach($sermons as $s): ?>
    <div class="sermon-card">
      <div class="sermon-date">
        <div class="day"><?php echo explode(' ', $s[2])[1]; ?></div>
        <div class="month"><?php echo explode(' ', $s[2])[0]; ?></div>
      </div>
      <div class="sermon-info">
        <h3><?php echo htmlspecialchars($s[0]); ?></h3>
        <div class="preacher">🎙 <?php echo htmlspecialchars($s[1]); ?> · <?php echo htmlspecialchars($s[3]); ?></div>
        <p><?php echo htmlspecialchars($s[4]); ?></p>
        <a href="<?php echo $s[5]; ?>" class="btn btn-gold" style="margin-top:1rem; font-size:11px; padding:10px 20px;">▶ Listen / Watch</a>
      </div>
    </div>
    <?php endforeach; ?>

    <div style="text-align:center; margin-top:3rem; padding:3rem; background:var(--navy); border-radius:10px;">
      <p style="color:var(--gold); font-family:'Cinzel',serif; font-size:1.1rem; margin-bottom:0.5rem;">More Sermons Coming</p>
      <p style="color:rgba(255,255,255,0.6); font-size:14px;">Branch admins can upload sermon recordings and notes through the admin panel. New messages are added regularly.</p>
    </div>
  </div>
</section>

<?php include '../includes/footer.php'; ?>
