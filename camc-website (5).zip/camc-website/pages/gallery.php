<?php
$pageTitle = 'Gallery - Events & Moments';
$pageDesc = 'Photo gallery of CAMC events, worship services, and community moments.';
$base = '../';
include '../includes/header.php';

// Gallery images data
$gallery = [
  ['DSC_1368.jpg', 'Woman Kneeling in Prayer', 'January Salvation Vigil 2026', 'A powerful moment of individual prayer during the January Salvation Vigil night service.'],
  ['DSC_1371.jpg', 'Congregation Dancing in Worship', 'January Salvation Vigil 2026', 'Members of the congregation dancing joyfully in praise during the vigil service.'],
  ['DSC_1375.jpg', 'Hands Raised in Worship', 'January Salvation Vigil 2026', 'The congregation lifts their hands in unified praise and worship.'],
  ['DSC_1381.jpg', 'Young Drummer Performing', 'January Salvation Vigil 2026', 'A talented young drummer leads the musical worship team with precision and energy.'],
  ['DSC_1384.jpg', 'Saxophonists in Praise', 'January Salvation Vigil 2026', 'Two saxophonists playing beautifully to usher in the presence of God.'],
  ['DSC_1388.jpg', 'Drum Kit Close-Up', 'January Salvation Vigil 2026', 'A close-up of the worship band drum kit in action during the night vigil.'],
  ['DSC_1393.jpg', 'Leadership on Stage — Year of New Beginning', 'January Salvation Vigil 2026', 'Church leadership standing before the "Year of New Beginning 2026" banner.'],
  ['DSC_1396.jpg', 'President in Worship', 'January Salvation Vigil 2026', 'The church president leading in praise and worship during the vigil.'],
  ['DSC_1404.jpg', 'Women Dancing with White Handkerchiefs', 'January Salvation Vigil 2026', 'Women waving white handkerchiefs as a symbol of victory and praise.'],
  ['DSC_1407.jpg', 'Intense Prayer Moment', 'January Salvation Vigil 2026', 'Members engaged in deep intercession and prayer during the service.'],
  ['DSC_1421.jpg', 'Full Congregation View', 'January Salvation Vigil 2026', 'A wide view of the large congregation gathered for the January Salvation Vigil.'],
  ['DSC_1423.jpg', 'Woman Raising Hands in Praise', 'January Salvation Vigil 2026', 'A worshipper raising her hands in exuberant praise to God.'],
  ['DSC_1439.jpg', 'Choir and Dancers Before the Altar', 'January Salvation Vigil 2026', 'Choir members and praise dancers ministering beautifully before the altar.'],
];
?>

<?php /* PAGE HERO */ ?>
<div class="page-hero" style="background-image: url('../assets/images/DSC_1375.jpg'); background-size:cover; background-position:center;">
  <div class="page-hero-content">
    <div class="breadcrumb">Home › Gallery</div>
    <h1>Photo Gallery</h1>
    <p style="color:rgba(255,255,255,0.7); margin-top:0.75rem; font-family:'Playfair Display',serif; font-style:italic; font-size:1.1rem;">
      Capturing moments of faith, praise, and community
    </p>
  </div>
</div>

<!-- GALLERY FILTER TABS -->
<section style="background:var(--cream); padding:40px 2rem 0;">
  <div class="section-inner">
    <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:0;">
      <button onclick="filterGallery('all')" class="filter-btn active" data-filter="all">All Photos</button>
      <button onclick="filterGallery('vigil2026')" class="filter-btn" data-filter="vigil2026">January Salvation Vigil 2026</button>
    </div>
  </div>
</section>

<style>
.filter-btn {
  padding: 10px 22px;
  background: transparent;
  border: 2px solid var(--gold);
  color: var(--navy);
  font-family: 'Lato', sans-serif;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  cursor: pointer;
  border-radius: 3px;
  transition: all 0.2s;
}
.filter-btn.active, .filter-btn:hover {
  background: var(--gold);
  color: var(--navy);
}

.gallery-page-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 16px;
}

.gallery-page-item {
  position: relative;
  overflow: hidden;
  border-radius: 8px;
  aspect-ratio: 4/3;
  cursor: pointer;
  background: var(--navy);
}

.gallery-page-item img {
  width: 100%; height: 100%;
  object-fit: cover;
  display: block;
  transition: transform 0.5s ease;
}

.gallery-page-item:hover img { transform: scale(1.06); }

.gallery-page-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to top, rgba(10,22,40,0.95) 0%, rgba(10,22,40,0.2) 60%, transparent 100%);
  opacity: 0;
  transition: opacity 0.3s;
  display: flex; flex-direction: column; justify-content: flex-end;
  padding: 1.5rem;
  color: var(--white);
}

.gallery-page-item:hover .gallery-page-overlay { opacity: 1; }

.gallery-page-overlay h4 {
  font-family: 'Cinzel', serif;
  font-size: 14px;
  font-weight: 700;
  margin-bottom: 4px;
  color: var(--white);
}

.gallery-page-overlay p {
  font-size: 12px;
  color: rgba(255,255,255,0.7);
  line-height: 1.5;
}

.gallery-page-overlay .event-tag {
  font-size: 10px;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: var(--gold);
  margin-bottom: 6px;
}

.gallery-count {
  font-family: 'Cinzel', serif;
  font-size: 13px;
  color: rgba(255,255,255,0.5);
  margin-bottom: 1.5rem;
}
</style>

<section style="background:var(--cream); padding:40px 2rem 100px;">
  <div class="section-inner">
    <p class="gallery-count"><?php echo count($gallery); ?> photos</p>
    <div class="gallery-page-grid" id="galleryGrid">
      <?php foreach($gallery as $i => $img): ?>
      <div class="gallery-page-item gallery-item" data-category="vigil2026">
        <img src="../assets/images/<?php echo $img[0]; ?>" alt="<?php echo htmlspecialchars($img[1]); ?>" loading="<?php echo $i < 6 ? 'eager' : 'lazy'; ?>">
        <div class="gallery-page-overlay">
          <div class="event-tag"><?php echo htmlspecialchars($img[2]); ?></div>
          <h4><?php echo htmlspecialchars($img[1]); ?></h4>
          <p><?php echo htmlspecialchars($img[3]); ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- UPLOAD PROMO BOX (for admins) -->
<section style="background:var(--navy); padding:60px 2rem;">
  <div class="section-inner" style="text-align:center;">
    <p class="section-label">For Church Leaders</p>
    <h2 class="section-title" style="color:var(--white);">Upload Event <span class="accent">Photos</span></h2>
    <p style="color:rgba(255,255,255,0.6); max-width:500px; margin:0 auto 2rem;">
      Branch admins and super admins can upload photos from events directly through the admin panel.
    </p>
    <a href="../admin/login.php" class="btn btn-gold">Admin Login to Upload</a>
  </div>
</section>

<script>
function filterGallery(filter) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  document.querySelectorAll('.gallery-page-item').forEach(item => {
    if (filter === 'all' || item.dataset.category === filter) {
      item.style.display = '';
    } else {
      item.style.display = 'none';
    }
  });
}
</script>

<?php include '../includes/footer.php'; ?>
