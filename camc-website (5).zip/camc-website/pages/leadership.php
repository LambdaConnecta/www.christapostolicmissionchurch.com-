<?php
$pageTitle = 'Leadership - CAMC';
$base = '../';
include '../includes/header.php';
?>

<div class="page-hero">
  <div class="page-hero-content">
    <div class="breadcrumb">Home › Leadership</div>
    <h1>Church Leadership</h1>
    <p style="color:rgba(255,255,255,0.7); margin-top:0.75rem; font-family:'Playfair Display',serif; font-style:italic;">
      Servants of God leading with faith, integrity, and vision
    </p>
  </div>
</div>

<style>
.leader-card {
  background: var(--white);
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 4px 24px rgba(0,0,0,0.08);
  transition: transform 0.3s, box-shadow 0.3s;
  text-align: center;
}
.leader-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 12px 40px rgba(10,22,40,0.15);
}
.leader-img {
  width: 140px; height: 140px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--gold), var(--deep-gold));
  margin: 2rem auto 1rem;
  display: flex; align-items: center; justify-content: center;
  font-size: 3.5rem;
  border: 4px solid var(--cream);
}
.leader-info { padding: 0 1.5rem 2rem; }
.leader-title {
  font-size: 11px;
  letter-spacing: 3px;
  text-transform: uppercase;
  color: var(--gold);
  font-weight: 700;
  margin-bottom: 0.3rem;
}
.leader-name {
  font-family: 'Cinzel', serif;
  font-size: 1.1rem;
  color: var(--navy);
  font-weight: 700;
  margin-bottom: 0.75rem;
}
.leader-desc {
  font-size: 13px;
  color: var(--gray);
  line-height: 1.7;
}
.deceased-badge {
  display: inline-block;
  background: rgba(139,26,26,0.1);
  color: var(--crimson);
  font-size: 10px;
  letter-spacing: 2px;
  text-transform: uppercase;
  padding: 3px 12px;
  border-radius: 20px;
  margin-bottom: 0.5rem;
  font-weight: 700;
}
</style>

<section style="background:var(--light-gray); padding:80px 2rem;">
  <div class="section-inner">
    <p class="section-label">Current Leadership</p>
    <h2 class="section-title">Present Day <span class="accent">Leadership</span></h2>
    <div class="divider"></div>
    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:2rem; margin-top:2rem;">
      <div class="leader-card">
        <div class="leader-img">👨‍💼</div>
        <div class="leader-info">
          <div class="leader-title">President, CAMC Worldwide</div>
          <h3 class="leader-name">Pastor John Babatunde, JP</h3>
          <p class="leader-desc">A teacher of the Word, a prophet, and an aggressive Gospel Evangelist. Appointed President of CAMC Worldwide in March 2023 following the transition of his predecessor.</p>
        </div>
      </div>
      <div class="leader-card">
        <div class="leader-img">🙏</div>
        <div class="leader-info">
          <div class="leader-title">National Secretary</div>
          <h3 class="leader-name">To Be Announced</h3>
          <p class="leader-desc">The national secretariat team coordinates all activities of CAMC branches across Nigeria from the national headquarters in Abule-Egba, Lagos.</p>
        </div>
      </div>
      <div class="leader-card">
        <div class="leader-img">📖</div>
        <div class="leader-info">
          <div class="leader-title">Director, College of Theology</div>
          <h3 class="leader-name">To Be Announced</h3>
          <p class="leader-desc">Oversees the training of ministers and leaders for the ever-expanding CAMC ministry across branches.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FOUNDING & PAST PRESIDENTS -->
<section style="background:var(--navy); padding:80px 2rem;">
  <div class="section-inner">
    <p class="section-label">Our Foundations</p>
    <h2 class="section-title" style="color:var(--white);">Founding &amp; Past <span class="accent">Presidents</span></h2>
    <div class="divider"></div>
    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:2rem; margin-top:2rem;">
      <div class="leader-card">
        <div class="leader-img">👑</div>
        <div class="leader-info">
          <div class="deceased-badge">Founder · In Glory</div>
          <div class="leader-title">Founder & First President</div>
          <h3 class="leader-name">Apostle John Ajayi Agbona</h3>
          <p class="leader-desc">Founded CAMC on December 13, 1952 at Bar Beach, Lagos. Originally illiterate, he was miraculously taught to read the Bible by God in a dream. Led the church through explosive growth until 2000.</p>
        </div>
      </div>
      <div class="leader-card">
        <div class="leader-img">🎵</div>
        <div class="leader-info">
          <div class="deceased-badge">In Glory · Jan 2022</div>
          <div class="leader-title">2nd President (2000–2022)</div>
          <h3 class="leader-name">Pastor Simeon Adesoji Ajayi, JP</h3>
          <p class="leader-desc">Affectionately known as <em>"Baba Olorin"</em> for his vast repertoire of worship songs. Established the Covenant of Prosperity Revival. Led CAMC for 21 years with great love and generosity.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include '../includes/footer.php'; ?>
