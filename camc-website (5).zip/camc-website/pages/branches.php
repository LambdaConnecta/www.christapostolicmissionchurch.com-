<?php
$pageTitle = 'Branches - Christ Apostolic Mission Church (CAMC)';
$base = '../';
include '../includes/header.php';

$branches = [
  ['Idi Oro (The Throne of God Parish) — HQ', '111/112, Agege Motor Road, Idi Oro Bus Stop, Mushin, Lagos', 'Lagos', 'hq'],
  ['Abule Egba (City of Praise Parish)', '1/5, C.A.M.C. Salvation Street, U-turn Bus Stop, Abule Egba', 'Lagos', 'lagos'],
  ['Ajegunle Parish', '3, Akinde Road, Ajegunle Bus Stop, Lagos State', 'Lagos', 'lagos'],
  ['Ojokoro Parish', '38, Adamu Fadehan Street, Ojokoro Ijaiye', 'Lagos', 'lagos'],
  ['Ojodu (Comfort Parish)', '5, Bola Street, Off Powerline Yakoyo Market, Ojodu', 'Lagos', 'lagos'],
  ['Ojodu Aina (Miracle City Parish)', '91/93, Aina Road, Ojodu-Lagos', 'Lagos', 'lagos'],
  ['Agege Atobaje (Mercy Seat Parish)', '24, Adebari Street, Opp Post Office AP Bus Stop, Agege', 'Lagos', 'lagos'],
  ['Agbado Oke-Odo (Divine Favour Parish)', '27, Omo Israel Street, Off Pleasure B/Stop, Oke-Odo, Agege', 'Lagos', 'lagos'],
  ["Alagbado (God's Own Parish)", 'Opposite Shop 45/47, Nureni Yussuf Lock-up Shop, Kollington Bus Stop', 'Lagos', 'lagos'],
  ['Amikanle (Crown of Glory Parish)', '8, Oremeji Street, Surulere-Amikanle, Alagbado', 'Lagos', 'lagos'],
  ['Ilapo (City of Worship Parish)', '9, Mbosi Street, Off AIT Road, Coca Cola Bus Stop, Alagbado', 'Lagos', 'lagos'],
  ['Abule Jesu (New Glory Parish)', '1, Adio Egberongbe Close, Alowonle B/stop, Abule Iroko', 'Lagos', 'lagos'],
  ['Ijaiye (Strong Tower Parish)', '16, Olaniyi Street, Ijaiye', 'Lagos', 'lagos'],
  ['Shomolu (City of Joy Parish)', '7, Eyiowuawi Street, Ita-Baale B/stop, Shomolu', 'Lagos', 'lagos'],
  ['Ilupeju (Glory of God Parish)', '65/67, Shyllon Street, Palmgroove Bus Stop, Ilupeju', 'Lagos', 'lagos'],
  ['Olorunsogo (City of Refuge Parish)', '26, Oliyide Street, Off Mushin Local Government HQ, Mushin', 'Lagos', 'lagos'],
  ['Ishaga (Peace Parish)', '16, Oyekanmi Street, Babalola Bus Stop, Itire Road, Mushin', 'Lagos', 'lagos'],
  ['Itire (Fountain of Peace Parish)', '73, Ola Street, Off Olayinka Street, Jonathan Bus Stop, Itire', 'Lagos', 'lagos'],
  ['Lawanson (City of Freedom Parish)', '9, Alafia Street, Otun Oba Bus Stop, Lawanson', 'Lagos', 'lagos'],
  ['Mafoluku (City of Angels Parish)', '1, Omilade Street, Mafoluku, Oshodi', 'Lagos', 'lagos'],
  ['Dopemu (City of Saviour Parish)', '55, Alhaji Bashorun Street, Dopemu', 'Lagos', 'lagos'],
  ['Ejigbo (Liberation Parish)', '46, Ejigbo Road, Daleko Bus Stop, Ejigbo', 'Lagos', 'lagos'],
  ["Oko Oba (Overcomer's Parish)", '8, Iyanda Falola Street, Cele Bus Stop, Oko Oba', 'Lagos', 'lagos'],
  ['Ikotun (City of Kings Parish)', '23, Adisa Idowu Street, Off Adejowo Street, Ikotun', 'Lagos', 'lagos'],
  ['Isheri (Liberty Parish)', '10, Magodo Road, Off Isheri Market, Isheri', 'Lagos', 'lagos'],
  ['Akesan (Glory Parish)', '1, Pacific Estate, Lasu Road, Ewedogbon Bus Stop, Akesan', 'Lagos', 'lagos'],
  ['Olakitan Ipaja (Fountain of Joy Parish)', '1, Osademe Street, Near Dafek School, Olakitan Ipaja', 'Lagos', 'lagos'],
  ['Ayobo (The Good Shepherd Parish)', '3, Araromi Street, Ayobo', 'Lagos', 'lagos'],
  ['Ikorodu (El-Shaddai Parish)', '5, Ife-Oluwa Street, Ikorodu, Idiroko B/Stop', 'Lagos', 'lagos'],
  ['Okerube (The True Vine Parish)', '23/25 Unity Avenue, Okerube', 'Lagos', 'lagos'],
  // OGUN
  ['Oja Odan (Marvelous Parish)', 'Expressroad, Oja Odan', 'Ogun', 'ogun'],
  ['Oba Eerin (Fulfilment Parish)', 'Off Abiola Polytechnic Road, Oba Eerin, Via Abeokuta', 'Ogun', 'ogun'],
  ['Ibafo (Charity Parish)', '1/5 CAMC Street, Magada Onigbagbo, Ibafo', 'Ogun', 'ogun'],
  ['Ogijo Parish', 'Owonikoko Street, Agowa, Ogijo', 'Ogun', 'ogun'],
  ['Sango Igbala Parish', 'Onibudo Avenue, Abestors B/Stop, Sango-Igbala', 'Ogun', 'ogun'],
  ['Sango Otta (Hallelujah Parish)', '11/13, Ifelodun Street, Behind Joju Hotel, Sango Otta', 'Ogun', 'ogun'],
  ['Ijako Parish', '15, Zacheous Bankole Street, Ijako, Sango Ota, Ogun State', 'Ogun', 'ogun'],
  ['Ifo (Classic Parish)', 'Lagos/Abeokuta Expressway, Sawmill Bus Stop, Palm Tree Plantation, Bungalow-Ifo', 'Ogun', 'ogun'],
  ['Iju Ota (The King of Joy Parish)', '14, Idi Iroko Road, Transformer Bus Stop, Iju Ota', 'Ogun', 'ogun'],
  ['Ijoko Ota (Anointed Parish)', '71, Agoro Road, Ogundele B/stop, Ijoko Ota', 'Ogun', 'ogun'],
  ['Ife Oluwa (Amazing Grace Parish)', 'Cross Soap Street, Ife-Oluwa Estate, Oju-Ore, Ota', 'Ogun', 'ogun'],
  ['Abeokuta (Victory Parish)', '1, CAMC Salvation Street, Off Sarkis Nursery & Primary School, Somorin B/Stop, Obantoko-Abeokuta', 'Ogun', 'ogun'],
  ['Ilaro (Possibility Parish)', 'Kunie Ibikunle Road, Asela Car Wash (Patiko) Ilaro, Ogun State', 'Ogun', 'ogun'],
  ['Ijebu-Ode (Success Parish)', '6, Ikudehin Street, Ijebu-Ode', 'Ogun', 'ogun'],
  ['Imodi Mosan (Diamond Parish)', 'Via Ijebu Ode', 'Ogun', 'ogun'],
  ['Isoyin-Ijebu (Promise Parish)', '2, Ijebu-ode Road, Isoyin', 'Ogun', 'ogun'],
  ['Ilese-Ijebu (Hosannah Parish)', '2, Ogojore Ward, Ilese', 'Ogun', 'ogun'],
  ['Ibeshe (Conqueror Parish)', 'Oke Ala Quarter, Igbogila Road, Ibeshe', 'Ogun', 'ogun'],
  ['Ijoun Jesutedo (Mount Zion Parish)', 'Ijoun, Jesutedo Okabatamu, Yewa North Ogun State', 'Ogun', 'ogun'],
  ['Ijoun Sopa (Living Stone Parish)', 'Sopa Road, Ijoun, Yewa North, Ogun State', 'Ogun', 'ogun'],
  ['Ijoun Abe Jesu (City of David Parish)', 'Abe Iroko Street, Ijoun', 'Ogun', 'ogun'],
  ['Onigbongbo Parish', '69, Hotel Road, Off Ajegunle Road, Atan Ota, Ogun State', 'Ogun', 'ogun'],
  ['Itire-Ajibawo Parish', '5, Oko Filling Street, Opp Good Shepherd Schools, Ajibawo, Atan Ota, Ogun State', 'Ogun', 'ogun'],
  ['Aladiye Parish', '1/3, CAMC Salvation Street, Aladiye Owe Town, Off Atan Agbara Road, Atan Ota, Ogun State', 'Ogun', 'ogun'],
  ['Torotoro Parish', 'Along Magbon Road, Torotoro, Lotto Bus Stop, Mowe, Ogun State', 'Ogun', 'ogun'],
  ['Matogun Parish', '3/5, Oluyole Gas Line, Koye Road, Matogun, Ogun State', 'Ogun', 'ogun'],
  // OYO
  ['Ibadan (Prosperity Parish)', 'Oni Street, Off Salvation Army Road, Ibadan', 'Oyo', 'oyo'],
  ['Bodija (Astern of Life Parish)', '5, Farayola Street, Isopako Bodija', 'Oyo', 'oyo'],
  ['Apata Alaro (Adonai Parish)', 'SW9/1410, Ado Alaro, Bembo Apata', 'Oyo', 'oyo'],
  ['Iwo (Seed of Life Parish)', '6, Agora Road, Iwo', 'Oyo', 'oyo'],
  // OSUN
  ['Oke Ila Orangun (Covenant Parish)', 'Barrack Road, Oke Ila Orangun', 'Osun', 'osun'],
  ['Ilesha (Wisdom Parish)', 'Ibala Road, Oloruntedo Ilesha', 'Osun', 'osun'],
  ['Ila Orangun (Favour Parish)', 'Oke Aloyin Road, Ila Orangun, Osun State', 'Osun', 'osun'],
  ['Ariyo (Word of Life Parish)', 'Ariyo Village, Via Ipoti, Osun State', 'Osun', 'osun'],
  ['Esinkin (Mustard Seed Parish)', 'Via Oke-Ila Orangun, Osun State', 'Osun', 'osun'],
  ['Ibokun (Saviour Parish)', 'Near Mustard Seed School, Off Temidire Street, Ibokun, Osun State', 'Osun', 'osun'],
  ['Ile-Ife (King of Solomon Parish)', '27/29 Soji Adeniyi Street, Beside Baale Okiji Residence, Igboya Area, Ile-Ife', 'Osun', 'osun'],
  // EKITI
  ['Ilawe Kajola (Covenant of God Parish)', '1, Mission Street, CAMC Salvation Road, Kajola, Ilawe, Ekiti State', 'Ekiti', 'ekiti'],
  ['Ilawe Okebedo (City of Prayer Parish)', 'Afunremu Street, Okebodo Quarters, Ilawe Ekiti, Ekiti State', 'Ekiti', 'ekiti'],
  ['Ado Ekiti (Emmanuel Parish)', '45, Taiye Fasugba Lane, Off Agric Road, Odo Ado, Ado Ekiti, Ekiti State', 'Ekiti', 'ekiti'],
  ['Ikere Afao (Astern of Joy Parish)', '2, Ayedun Street, Afao Quarters, Ikere Ekiti', 'Ekiti', 'ekiti'],
  ['Ikere Araromi (Bread of Life Parish)', 'Olumoroko Street, Beside Vulcanizer Hall, Ikere Ekiti', 'Ekiti', 'ekiti'],
  ['Igede Ekiti (Fountain of Peace Parish)', '45, Aaye Quarters, Off Ilogbo Street, Igede, Ekiti', 'Ekiti', 'ekiti'],
  ['Ijero Ekiti (Joy Parish)', '7, Otitolere Street, Off Oke-Oro Road, Ijero Ekiti', 'Ekiti', 'ekiti'],
  // ONDO
  ['Akure (Palace of Peace Parish)', '21, Fayanju Street, Off Leo Junction, Oyemekun, Akure, Ondo State', 'Ondo', 'ondo'],
  // DELTA
  ['Sapele (Aroma of God Parish)', '193, Behind Okirigwre Market, Sapele, Warri Road, Delta State', 'Delta', 'delta'],
  // KOGI
  ['Kabba (Chosen of God Parish)', '17, Odi Olowo Quarters, Kabba, Kogi State', 'Kogi', 'kogi'],
  // UK
  ['UK — City of Gold Parish', '429-431 Rainham Road South, Dagenham, Essex RM10 8XE, United Kingdom', 'United Kingdom', 'uk'],
];

$stateColors = [
  'Lagos'=>'#C9A84C','Ogun'=>'#4C9AC9','Oyo'=>'#C94C4C',
  'Osun'=>'#4CAF50','Ekiti'=>'#9A4CC9','Ondo'=>'#FF8C42',
  'Delta'=>'#4CC9C9','Kogi'=>'#C9C94C','United Kingdom'=>'#4C5BC9',
];
$grouped = [];
foreach($branches as $b) { $grouped[$b[2]][] = $b; }
$ordered = [];
if (isset($grouped['Lagos'])) { $ordered['Lagos'] = $grouped['Lagos']; unset($grouped['Lagos']); }
if (isset($grouped['Ogun'])) { $ordered['Ogun'] = $grouped['Ogun']; unset($grouped['Ogun']); }
foreach($grouped as $k => $v) $ordered[$k] = $v;
?>

<div class="page-hero" style="background-image:url('../assets/images/DSC_1375.jpg'); background-size:cover; background-position:center;">
  <div class="page-hero-content">
    <div class="breadcrumb">Home › Branches</div>
    <h1>Our Branches</h1>
    <p style="color:rgba(255,255,255,0.75); margin-top:0.75rem; font-family:'Playfair Display',serif; font-style:italic; font-size:1.1rem;">
      <?php echo count($branches); ?> parishes spreading the gospel across Nigeria &amp; United Kingdom
    </p>
  </div>
</div>

<style>
.branch-filter-bar{background:var(--navy);padding:1.2rem 2rem;border-bottom:1px solid rgba(201,168,76,0.2);position:sticky;top:70px;z-index:100;}
.branch-filter-inner{max-width:1280px;margin:0 auto;display:flex;gap:8px;flex-wrap:wrap;align-items:center;}
.sfb{padding:6px 16px;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);border-radius:20px;color:rgba(255,255,255,0.6);font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;cursor:pointer;transition:all 0.2s;font-family:'Lato',sans-serif;}
.sfb:hover,.sfb.active{background:var(--gold);border-color:var(--gold);color:var(--navy);}
.bc-badge{background:rgba(201,168,76,0.15);color:var(--gold);border:1px solid rgba(201,168,76,0.3);border-radius:20px;padding:4px 14px;font-size:11px;font-weight:700;letter-spacing:1px;margin-left:auto;}
.bss{margin-bottom:2.5rem;}
.bsh{display:flex;align-items:center;gap:12px;margin-bottom:1.2rem;padding-bottom:0.75rem;border-bottom:2px solid rgba(201,168,76,0.2);}
.sdot{width:14px;height:14px;border-radius:50%;flex-shrink:0;}
.bsh h3{font-family:'Cinzel',serif;font-size:1rem;color:var(--navy);font-weight:700;}
.bcp{background:var(--navy);color:var(--gold);font-size:10px;font-weight:700;padding:2px 12px;border-radius:20px;margin-left:auto;letter-spacing:1px;}
.blg{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:10px;}
.bli{background:#fff;border-radius:6px;padding:1rem 1.2rem;border-left:4px solid var(--gold);box-shadow:0 2px 8px rgba(0,0,0,0.05);transition:transform 0.2s;}
.bli:hover{transform:translateY(-2px);}
.bli.hqi{background:linear-gradient(135deg,var(--navy),#1a2a4a);border-left-color:var(--gold);}
.bn{font-family:'Cinzel',serif;font-size:12px;font-weight:700;color:var(--navy);line-height:1.3;}
.hqi .bn{color:var(--gold);font-size:13px;}
.ba{font-size:12px;color:var(--gray);line-height:1.5;margin-top:3px;}
.hqi .ba{color:rgba(255,255,255,0.6);}
.hq-b{display:inline-flex;align-items:center;gap:5px;background:var(--gold);color:var(--navy);font-size:9px;font-weight:900;letter-spacing:2px;text-transform:uppercase;padding:2px 10px;border-radius:20px;margin-bottom:4px;width:fit-content;}
.uk-b{background:rgba(76,91,201,0.2);color:#818cf8;border:1px solid rgba(76,91,201,0.3);font-size:9px;font-weight:700;letter-spacing:1px;padding:2px 10px;border-radius:20px;margin-bottom:4px;width:fit-content;text-transform:uppercase;}
</style>

<!-- FILTER BAR -->
<div class="branch-filter-bar">
  <div class="branch-filter-inner">
    <button class="sfb active" onclick="fs('all',this)">All</button>
    <?php foreach(array_keys($ordered) as $st): ?>
    <button class="sfb" onclick="fs('<?php echo strtolower(str_replace(' ','-',$st)); ?>',this)"><?php echo $st; ?></button>
    <?php endforeach; ?>
    <span class="bc-badge" id="bCount"><?php echo count($branches); ?> Branches</span>
  </div>
</div>

<!-- STATS -->
<div style="background:linear-gradient(135deg,var(--navy),var(--crimson));padding:40px 2rem;">
  <div style="max-width:900px;margin:0 auto;display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;text-align:center;">
    <div><div style="font-family:'Cinzel',serif;font-size:2.5rem;font-weight:900;color:var(--gold);"><?php echo count($branches); ?></div><div style="font-size:10px;letter-spacing:3px;color:rgba(255,255,255,0.55);margin-top:3px;text-transform:uppercase;">Total Parishes</div></div>
    <div><div style="font-family:'Cinzel',serif;font-size:2.5rem;font-weight:900;color:var(--gold);"><?php echo count($ordered); ?></div><div style="font-size:10px;letter-spacing:3px;color:rgba(255,255,255,0.55);margin-top:3px;text-transform:uppercase;">States + UK</div></div>
    <div><div style="font-family:'Cinzel',serif;font-size:2.5rem;font-weight:900;color:var(--gold);">1952</div><div style="font-size:10px;letter-spacing:3px;color:rgba(255,255,255,0.55);margin-top:3px;text-transform:uppercase;">Year Founded</div></div>
    <div><div style="font-family:'Cinzel',serif;font-size:2.5rem;font-weight:900;color:var(--gold);">1</div><div style="font-size:10px;letter-spacing:3px;color:rgba(255,255,255,0.55);margin-top:3px;text-transform:uppercase;">UK Parish</div></div>
  </div>
</div>

<!-- BRANCHES LIST -->
<section style="background:var(--light-gray);padding:60px 2rem 100px;">
  <div class="section-inner">

    <?php foreach($ordered as $state => $stateBranches):
      $slug = strtolower(str_replace(' ','-',$state));
      $dc = $stateColors[$state] ?? '#C9A84C';
    ?>
    <div class="bss" data-state="<?php echo $slug; ?>">
      <div class="bsh">
        <div class="sdot" style="background:<?php echo $dc; ?>;box-shadow:0 0 8px <?php echo $dc; ?>66;"></div>
        <h3><?php echo htmlspecialchars($state); ?></h3>
        <div class="bcp"><?php echo count($stateBranches); ?> Parish<?php echo count($stateBranches)>1?'es':''; ?></div>
      </div>
      <div class="blg">
        <?php foreach($stateBranches as $b):
          $isHQ = ($b[3]==='hq'); $isUK = ($b[3]==='uk');
        ?>
        <div class="bli <?php echo $isHQ?'hqi':''; ?>">
          <?php if($isHQ): ?><div class="hq-b">★ National Headquarters</div><?php endif; ?>
          <?php if($isUK): ?><div class="uk-b">🇬🇧 United Kingdom</div><?php endif; ?>
          <div class="bn"><?php echo htmlspecialchars($b[0]); ?></div>
          <div class="ba">📍 <?php echo htmlspecialchars($b[1]); ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>

    <div id="noRes" style="display:none;text-align:center;padding:4rem;color:var(--gray);font-style:italic;">No branches found.</div>

    <div style="text-align:center;margin-top:3rem;padding:3rem 2rem;background:linear-gradient(135deg,var(--navy),#1a2a4a);border-radius:12px;border:1px solid rgba(201,168,76,0.2);">
      <p style="font-family:'Cinzel',serif;font-size:1.2rem;color:var(--gold);margin-bottom:0.5rem;">Plant a Branch Near You</p>
      <p style="color:rgba(255,255,255,0.6);font-size:14px;max-width:500px;margin:0 auto 1.5rem;">Interested in starting a CAMC parish in your community? Contact the National Secretariat for guidance.</p>
      <a href="contact.php" class="btn btn-gold">Contact Head Office</a>
      <p style="color:rgba(255,255,255,0.3);font-size:12px;margin-top:1rem;">📞 +2347048700005 · 1/5 CAMC Salvation Street, Abule-Egba, Lagos</p>
    </div>
  </div>
</section>

<script>
function fs(state, btn) {
  document.querySelectorAll('.sfb').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const secs = document.querySelectorAll('.bss');
  let tot = 0;
  secs.forEach(s => {
    if (state==='all' || s.dataset.state===state) { s.style.display=''; tot+=s.querySelectorAll('.bli').length; }
    else s.style.display='none';
  });
  document.getElementById('bCount').textContent = tot + ' Branches';
  document.getElementById('noRes').style.display = tot===0 ? 'block' : 'none';
}
</script>

<?php include '../includes/footer.php'; ?>
