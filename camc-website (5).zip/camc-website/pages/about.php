<?php
$pageTitle = 'About CAMC - Our History & Mission';
$pageDesc = 'Learn about the Christ Apostolic Mission Church founded in 1952 by Apostle John Ajayi Agbona.';
$base = '../';
include '../includes/header.php';
?>

<div class="page-hero" style="background-image:url('../assets/images/DSC_1393.jpg'); background-size:cover; background-position:center top;">
  <div class="page-hero-content">
    <div class="breadcrumb">Home › About</div>
    <h1>Our Story</h1>
    <p style="color:rgba(255,255,255,0.7); margin-top:0.75rem; font-family:'Playfair Display',serif; font-style:italic; font-size:1.1rem;">
      Founded on divine obedience · Est. December 13, 1952
    </p>
  </div>
</div>

<style>
.about-content {
  max-width: 820px;
  margin: 0 auto;
}
.about-content h2 {
  font-family: 'Cinzel', serif;
  font-size: 1.5rem;
  color: var(--navy);
  margin-top: 3rem;
  margin-bottom: 1rem;
  padding-left: 1rem;
  border-left: 4px solid var(--gold);
}
.about-content p {
  font-size: 1.05rem;
  line-height: 1.95;
  color: #2d3748;
  margin-bottom: 1.2rem;
}
.about-content blockquote {
  background: var(--cream);
  border-left: 5px solid var(--gold);
  padding: 1.5rem 2rem;
  margin: 2rem 0;
  font-family: 'Playfair Display', serif;
  font-size: 1.1rem;
  font-style: italic;
  color: var(--navy);
  border-radius: 0 8px 8px 0;
}
.timeline-dot {
  display: inline-block;
  width: 12px; height: 12px;
  background: var(--gold);
  border-radius: 50%;
  margin-right: 10px;
}
</style>

<section style="background:var(--white); padding:80px 2rem;">
  <div class="section-inner">
    <!-- Lead summary -->
    <div style="text-align:center; max-width:700px; margin:0 auto 60px;">
      <p class="section-label">Est. 1952</p>
      <h2 class="section-title">Christ Apostolic <span class="accent">Mission Church</span></h2>
      <div class="divider center"></div>
      <p style="font-size:1.1rem; color:#4a5568; line-height:1.9;">
        The Christ Apostolic Mission Church (CAMC) is a Pentecostal denomination founded in Nigeria, with its roots tied to the broader Christ Apostolic Church movement but established as an independent entity on December 13, 1952.
      </p>
    </div>

    <!-- History Content -->
    <div class="about-content">

      <h2>Founder & Early Beginnings</h2>
      <p>The church was founded by <strong>Apostle John Ajayi Agbona</strong>, who began his ministry as an itinerant preacher within the Christ Apostolic Church. Originally illiterate, Apostle Agbona experienced a miraculous event where God taught him to read the Bible in a dream, which astonished those familiar with him.</p>
      <p>His early work in the Ogunpa area of Ibadan, Nigeria, was marked by signs and wonders, including praying for a woman who had been pregnant for seven years to safely conceive and deliver, as well as a witch who confessed and submitted to divine power during his ministry. Agbona eventually became a full-time minister in the Christ Apostolic Church, leading evangelical revivals accompanied by miraculous healings and spiritual manifestations.</p>

      <h2>Divine Call to Independence</h2>
      <p>After serving in the Christ Apostolic Church, Apostle Agbona received divine instructions to separate and establish his own ministry. On <strong>November 22, 1952</strong>, God directed him to give away all his possessions to the poor, starting with his bedspread. This was followed by further commands on December 5, 1952, to relinquish nearly everything except basic clothing items — a pair of knickers, a white 'buba', trousers, and a small 'agbada'.</p>

      <blockquote>
        "Would he ask to know why God gave instruction since God is his Lord and God is always good." — Apostle John Ajayi Agbona
      </blockquote>

      <p>God then told him that long and many as the coaches of the train might be, it will never be spacious enough to carry his properties by the time he would leave Lagos. He shared this divine leading with the authorities of the church, and he was formally released in 1952. With support from Apostle Babalola, he founded his church on <strong>December 13, 1952</strong>.</p>

      <h2>Official Founding & Initial Growth</h2>
      <p>On December 13, 1952, Agbona initially named the church the <em>Apostolic Mission Church</em> during its inaugural gathering at <strong>Bar Beach in Lagos</strong>. In a subsequent dream, God instructed him to prefix "Christ" to the name, resulting in <strong>Christ Apostolic Mission Church</strong>.</p>
      <p>The founding group started small: Apostle Agbona was joined by two young men at the beach, and two more arrived, making five in total. They launched an evangelistic campaign from Ojo Street in Mushin, Lagos, beginning with an open-air service at 4 p.m. By the end of that first service, <strong>20 people</strong> followed him back to Ojo Street for prayer, becoming the church's founding members.</p>
      <p>The following day, December 14, 1952, during the second service at <strong>42 Ojo Street, Odi-Olowo, Mushin</strong>, notable conversions occurred. Master Michael Tunde Kuku, a graduate of Igbobi College and former Muslim, encountered Christ and joined, later rising to become the church's Vice President. A church committee was quickly formed, with Apostle Agbona as chairman, Mr. Ogundare as secretary, and Mr. Ige as treasurer.</p>

      <h2>Relocations & Expansion</h2>
      <p>The church's headquarters relocated several times in its early years to accommodate growth. It moved from 42 Ojo Street to Akala Street in 1955, then temporarily to Mushin Public School on Aletile Street along Ikorodu Road, followed by a brief stay in a friend's sitting room on Agbekolade Street.</p>
      <p>By the late 1950s, it settled permanently at <strong>6 Iyasuna Street, Idi-Oro, Mushin, Lagos State</strong>, where the building was renovated in 1979. Under Apostle Agbona's leadership, CAMC grew rapidly through revivals, and God's promise that educated individuals would join was fulfilled, with graduates and professionals becoming part of the congregation.</p>
      <p>The church planted several parishes across Nigeria and established a <strong>College of Theology</strong> to train ministers for its expanding operations.</p>

      <h2>Covenant of Prosperity</h2>
      <p>On <strong>September 23, 2001</strong>, Pastor Simeon Adesoji Ajayi, the President of Christ Apostolic Mission Church Worldwide (CAMC W/W), announced to the entire church that God had instructed him to assemble the whole congregation at the National Secretariat, 1/5 CAMC Salvation Street, U-Turn Bus Stop, Abule-Egba, Lagos, where God would establish a Covenant of Prosperity with the church.</p>
      <p>Since that time, God has remained faithful to this covenant. This divine encounter gave rise to the <strong>Annual Covenant of Prosperity Revival</strong>, which is held every September to commemorate God's faithfulness and His unwavering love for the church.</p>

      <h2>Leadership Transition</h2>
      <p>Guided by divine instruction, Apostle Agbona handed over administrative leadership to <strong>Pastor Simon Adesoji Ajayi</strong> as the new president (August 19, 2000) while Agbona was still alive, ensuring a smooth transition. Under this new era, the church continued to expand in structure, scope, and services. A significant renovation of the headquarters in 2013 enhanced its facilities and appearance.</p>
      <p>After leading the Mission for 21 years, Pastor Simeon Adesoji Ajayi JP transitioned into glory in <strong>January 2022</strong>. He is fondly remembered as <em>"Baba Olorin"</em>, a title earned for his vast repertoire of songs devoted to the praise and worship of God. He was also a philanthropist, known as a cheerful and generous giver.</p>
      <p>Following his passing, his Vice President, <strong>Pastor John Babatunde, JP</strong> — a teacher of the Word, a prophet, and an aggressive Gospel Evangelist — was appointed President of the Christ Apostolic Mission Church Worldwide (CAMC W/W) in <strong>March 2023</strong>. Glory be to God Almighty!</p>

      <blockquote>
        "Today, CAMC remains a vibrant Pentecostal church focused on evangelism, miracles, and spiritual growth, primarily based in Nigeria but with a legacy tied to its founder's obedience to divine calls and the broader African Pentecostal tradition."
      </blockquote>
    </div>
  </div>
</section>

<!-- MISSION & VISION -->
<section style="background:var(--navy); padding:80px 2rem;">
  <div class="section-inner">
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:60px;">
      <div>
        <p class="section-label">Who We Are</p>
        <h2 class="section-title" style="color:var(--white);">Our <span class="accent">Mission</span></h2>
        <div class="divider"></div>
        <p style="color:rgba(255,255,255,0.75); font-size:1.05rem; line-height:1.9;">
          To preach the gospel of Jesus Christ with signs and wonders, to disciple nations, to heal the broken-hearted, and to build a community of believers who walk in the covenant promises of God.
        </p>
      </div>
      <div>
        <p class="section-label">Where We're Going</p>
        <h2 class="section-title" style="color:var(--white);">Our <span class="accent">Vision</span></h2>
        <div class="divider"></div>
        <p style="color:rgba(255,255,255,0.75); font-size:1.05rem; line-height:1.9;">
          To be a global Pentecostal movement that transforms every sphere of society through the power of the Holy Spirit, establishing thriving branches across Nigeria and beyond.
        </p>
      </div>
    </div>
  </div>
</section>

<?php include '../includes/footer.php'; ?>
