<?php
$pageTitle = 'Contact - Christ Apostolic Mission Church (CAMC)';
$base = '../';

define('CHURCH_EMAIL', 'info@christapostolicmissionchurch.com');
define('CHURCH_NAME',  'Christ Apostolic Mission Church (CAMC)');
define('WA_NUMBER',    '+2347048700005');

$msg = ''; $msgType = ''; $name = ''; $email = ''; $phone = ''; $message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['name'])) {

    // Honeypot check
    if (!empty($_POST['website'])) { exit; }

    $name    = htmlspecialchars(trim($_POST['name']    ?? ''));
    $email   = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $phone   = htmlspecialchars(trim($_POST['phone']   ?? ''));
    $subject = htmlspecialchars(trim($_POST['subject'] ?? 'General Enquiry'));
    $message = htmlspecialchars(trim($_POST['message'] ?? ''));
    $date    = date('l, F j, Y \a\t H:i');

    if (empty($name) || empty($email) || empty($message)) {
        $msg = 'Please fill in all required fields (Name, Email, Message).';
        $msgType = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = 'Please enter a valid email address.';
        $msgType = 'error';
    } else {
        $emailBody = "<!DOCTYPE html><html><head><meta charset='UTF-8'><style>
  body{font-family:Arial,sans-serif;background:#f5f5f5;margin:0;padding:0;}
  .wrap{max-width:600px;margin:30px auto;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.1);}
  .hdr{background:linear-gradient(135deg,#0A1628,#8B1A1A);padding:28px;text-align:center;}
  .hdr h2{color:#C9A84C;font-size:20px;margin:0;letter-spacing:2px;}
  .hdr p{color:rgba(255,255,255,0.6);font-size:12px;margin:5px 0 0;}
  .bdy{padding:28px;}
  .row{margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid #f0f0f0;}
  .row:last-child{border-bottom:none;margin-bottom:0;}
  .lbl{font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#9B6F1A;margin-bottom:4px;}
  .val{font-size:14px;color:#333;line-height:1.6;}
  .ftr{background:#f8f8f8;padding:18px;text-align:center;font-size:11px;color:#999;border-top:2px solid #C9A84C;}
  .btn{display:inline-block;background:#C9A84C;color:#0A1628;padding:11px 26px;border-radius:5px;text-decoration:none;font-weight:700;font-size:13px;margin-top:14px;}
</style></head><body>
<div class='wrap'>
  <div class='hdr'><h2>NEW CONTACT MESSAGE</h2><p>Christ Apostolic Mission Church Website</p></div>
  <div class='bdy'>
    <div class='row'><div class='lbl'>From</div><div class='val'><strong>" . $name . "</strong> &lt;" . $email . "&gt;</div></div>
    <div class='row'><div class='lbl'>Phone / WhatsApp</div><div class='val'>" . ($phone ?: 'Not provided') . "</div></div>
    <div class='row'><div class='lbl'>Subject</div><div class='val'>" . $subject . "</div></div>
    <div class='row'><div class='lbl'>Message</div><div class='val'>" . nl2br($message) . "</div></div>
    <div class='row'><div class='lbl'>Date &amp; Time</div><div class='val'>" . $date . "</div></div>
    <div style='text-align:center;'><a href='mailto:" . $email . "' class='btn'>Reply to " . $name . "</a></div>
  </div>
  <div class='ftr'>Sent via the CAMC website contact form &bull; Christ Apostolic Mission Church &bull; Lagos, Nigeria</div>
</div></body></html>";

        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: CAMC Website <noreply@christapostolicmissionchurch.com>\r\n";
        $headers .= "Reply-To: " . $name . " <" . $email . ">\r\n";

        $sent = mail(CHURCH_EMAIL, "[CAMC Website] " . $subject . " from " . $name, $emailBody, $headers);

        // Auto-reply to sender
        $replyBody = "<!DOCTYPE html><html><head><meta charset='UTF-8'><style>
  body{font-family:Arial,sans-serif;background:#f5f5f5;margin:0;padding:0;}
  .wrap{max-width:580px;margin:30px auto;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.1);}
  .hdr{background:linear-gradient(135deg,#0A1628,#8B1A1A);padding:28px;text-align:center;}
  .hdr h2{color:#C9A84C;font-size:20px;margin:0;}
  .hdr p{color:rgba(255,255,255,0.6);font-size:12px;margin:5px 0 0;}
  .bdy{padding:28px;color:#333;font-size:14px;line-height:1.8;}
  .verse{background:#FDF8EE;border-left:4px solid #C9A84C;padding:12px 16px;margin:16px 0;font-style:italic;color:#9B6F1A;}
  .ftr{background:#f8f8f8;padding:18px;text-align:center;font-size:11px;color:#999;border-top:2px solid #C9A84C;}
  .ftr a{color:#C9A84C;text-decoration:none;}
</style></head><body>
<div class='wrap'>
  <div class='hdr'><h2>Message Received ✅</h2><p>Christ Apostolic Mission Church</p></div>
  <div class='bdy'>
    <p>Dear <strong>" . $name . "</strong>,</p>
    <p>Thank you for contacting <strong>Christ Apostolic Mission Church (CAMC)</strong>. We have received your message and will respond as soon as possible.</p>
    <p>For urgent matters, you can also reach us on WhatsApp:<br>📞 <strong>" . WA_NUMBER . "</strong></p>
    <div class='verse'>\"The LORD bless you and keep you; the LORD make his face shine on you and be gracious to you.\"<br>&mdash; Numbers 6:24–25</div>
    <p>God bless you,<br><strong>CAMC Administration</strong></p>
  </div>
  <div class='ftr'>
    1/5 CAMC Salvation Street, Abule-Egba, Lagos State<br>
    <a href='mailto:" . CHURCH_EMAIL . "'>" . CHURCH_EMAIL . "</a> &bull; " . WA_NUMBER . "
  </div>
</div></body></html>";

        $rh  = "MIME-Version: 1.0\r\n";
        $rh .= "Content-Type: text/html; charset=UTF-8\r\n";
        $rh .= "From: CAMC <" . CHURCH_EMAIL . ">\r\n";
        mail($email, "We received your message — CAMC", $replyBody, $rh);

        // Backup log
        $logDir = dirname(__FILE__) . '/../includes/data/';
        if (is_writable($logDir)) {
            file_put_contents($logDir . 'contact_log.txt',
                date('Y-m-d H:i:s') . " | $name | $email | $phone | $subject\n", FILE_APPEND);
        }

        if ($sent) {
            $msg = "Thank you, <strong>$name</strong>! Your message has been sent to CAMC. We'll get back to you soon. A confirmation was sent to your email.";
            $msgType = 'success';
            $name = $email = $phone = $message = '';
        } else {
            $msg = "Our email server is temporarily unavailable. Please contact us directly via <a href='https://wa.me/2347048700005' target='_blank' style='color:#25D366;font-weight:700;'>WhatsApp</a> or call <strong>" . WA_NUMBER . "</strong>.";
            $msgType = 'warning';
        }
    }
}

include '../includes/header.php';
?>

<div class="page-hero">
  <div class="page-hero-content">
    <div class="breadcrumb">Home › Contact</div>
    <h1>Contact Us</h1>
    <p style="color:rgba(255,255,255,0.7); margin-top:0.75rem; font-family:'Playfair Display',serif; font-style:italic;">
      We'd love to hear from you
    </p>
  </div>
</div>

<section class="contact-section">
  <div class="section-inner">
    <div class="contact-grid">

      <div>
        <p class="section-label">Get in Touch</p>
        <h2 class="section-title" style="color:var(--white);">Visit or <span class="accent">Contact Us</span></h2>
        <div class="divider"></div>

        <div class="contact-info-item">
          <div class="contact-icon">📍</div>
          <div class="contact-text">
            <h4>National Secretariat</h4>
            <p>1/5 CAMC Salvation Street, Off Yisa Oladimeji Street<br>U-Turn Bus-Stop, Abule-Egba, Lagos State</p>
          </div>
        </div>
        <div class="contact-info-item">
          <div class="contact-icon">📞</div>
          <div class="contact-text">
            <h4>Phone / WhatsApp</h4>
            <p>
              <a href="tel:+2347048700005" style="color:rgba(255,255,255,0.75);">+234 7048700005</a><br>
              <a href="https://wa.me/2347048700005" target="_blank"
                 style="color:#25D366;font-weight:700;font-size:13px;display:inline-flex;align-items:center;gap:6px;margin-top:4px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                Chat on WhatsApp
              </a>
            </p>
          </div>
        </div>
        <div class="contact-info-item">
          <div class="contact-icon">✉</div>
          <div class="contact-text">
            <h4>Email</h4>
            <p><a href="mailto:<?php echo CHURCH_EMAIL; ?>" style="color:var(--gold);"><?php echo CHURCH_EMAIL; ?></a></p>
          </div>
        </div>
        <div class="contact-info-item">
          <div class="contact-icon">🕐</div>
          <div class="contact-text">
            <h4>Office Hours</h4>
            <p>Monday – Friday: 9:00am – 5:00pm<br>Saturdays: 9:00am – 1:00pm</p>
          </div>
        </div>
        <div class="contact-info-item">
          <div class="contact-icon">⛪</div>
          <div class="contact-text">
            <h4>Sunday Services</h4>
            <p>First Service: 7:00am – 9:00am<br>Sunday School: 9:00am – 10:00am<br>Second Service: 10:00am – 1:00pm</p>
          </div>
        </div>

        <a href="https://wa.me/2347048700005?text=<?php echo urlencode('Hello CAMC! I visited your website and would like to get in touch. 🙏'); ?>"
           target="_blank"
           style="display:inline-flex;align-items:center;gap:10px;background:#25D366;color:#fff;padding:14px 24px;border-radius:8px;text-decoration:none;font-weight:700;font-size:14px;margin-top:0.5rem;box-shadow:0 4px 16px rgba(37,211,102,0.4);">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
          Message us on WhatsApp
        </a>
      </div>

      <div>
        <p class="section-label" style="color:var(--gold);">Send a Message</p>
        <h2 class="section-title" style="color:var(--white); font-size:1.5rem;">Write to Us</h2>
        <p style="color:rgba(255,255,255,0.5); font-size:13px; margin-bottom:1.5rem;">
          Messages go directly to <strong style="color:var(--gold);"><?php echo CHURCH_EMAIL; ?></strong>
        </p>

        <?php if ($msg): ?>
        <div style="padding:1rem 1.2rem; border-radius:8px; margin-bottom:1.5rem; font-size:13px; line-height:1.6;
             background:<?php echo $msgType==='success' ? 'rgba(34,197,94,0.15)' : ($msgType==='error' ? 'rgba(239,68,68,0.15)' : 'rgba(245,158,11,0.15)'); ?>;
             border:1px solid <?php echo $msgType==='success' ? '#22c55e' : ($msgType==='error' ? '#ef4444' : '#f59e0b'); ?>;
             color:<?php echo $msgType==='success' ? '#22c55e' : ($msgType==='error' ? '#ef4444' : '#f59e0b'); ?>;">
          <?php echo $msgType==='success' ? '✅ ' : '⚠ '; echo $msg; ?>
        </div>
        <?php endif; ?>

        <form class="contact-form" method="POST" action="">
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
            <input type="text"  name="name"    placeholder="Your Full Name *"   required value="<?php echo htmlspecialchars($name); ?>">
            <input type="email" name="email"   placeholder="Email Address *"    required value="<?php echo htmlspecialchars($email); ?>">
          </div>
          <input type="tel"  name="phone"   placeholder="Phone / WhatsApp (optional)" value="<?php echo htmlspecialchars($phone); ?>">
          <select name="subject">
            <option>General Enquiry</option>
            <option>New Member Registration</option>
            <option>Prayer Request</option>
            <option>Event Information</option>
            <option>Branch Information</option>
            <option>Counselling</option>
            <option>Donation / Tithe</option>
            <option>Other</option>
          </select>
          <textarea name="message" placeholder="Your message... *" required><?php echo htmlspecialchars($message); ?></textarea>
          <!-- Honeypot -->
          <input type="text" name="website" style="display:none;" tabindex="-1" autocomplete="off">
          <button type="submit" class="btn btn-gold" style="width:100%;">✉ Send Message to CAMC</button>
          <p style="text-align:center;color:rgba(255,255,255,0.25);font-size:11px;margin-top:0.6rem;letter-spacing:1px;">
            Sent directly to <?php echo CHURCH_EMAIL; ?>
          </p>
        </form>
      </div>
    </div>
  </div>
</section>

<div style="background:#050D1A; padding:16px 2rem; text-align:center;">
  <p style="color:rgba(255,255,255,0.3); font-size:11px; letter-spacing:2px; text-transform:uppercase; margin-bottom:10px;">
    📍 1/5 CAMC Salvation Street · U-Turn Bus Stop · Abule-Egba · Lagos
  </p>
  <iframe src="https://maps.google.com/maps?q=Abule+Egba+Lagos+Nigeria&output=embed"
    width="100%" height="260"
    style="border:0;display:block;opacity:0.75;border-radius:8px;max-width:1200px;margin:0 auto;"
    allowfullscreen="" loading="lazy">
  </iframe>
</div>

<?php include '../includes/footer.php'; ?>
