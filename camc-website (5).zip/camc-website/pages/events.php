<?php
$pageTitle = 'Events - CAMC';
$base = '../';
include '../includes/header.php';
?>

<div class="page-hero" style="background-image:url('../assets/images/DSC_1404.jpg'); background-size:cover; background-position:center;">
  <div class="page-hero-content">
    <div class="breadcrumb">Home › Events</div>
    <h1>Events</h1>
    <p style="color:rgba(255,255,255,0.7); margin-top:0.75rem; font-family:'Playfair Display',serif; font-style:italic;">
      Programmes, revivals and special services
    </p>
  </div>
</div>

<section style="background:var(--cream); padding:80px 2rem;">
  <div class="section-inner">
    <p class="section-label">Recurring Monthly</p>
    <h2 class="section-title">Monthly <span class="accent">Programmes</span></h2>
    <div class="divider"></div>
    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:1.5rem; margin-top:2rem;">
      <?php
      $monthly = [
        ['🌙', 'Salvation Night', 'First Friday of Every Month', 'An all-night prayer meeting with salvation altar calls. Bring the unsaved, the sick, and those in need of breakthrough.', 'Monthly · First Friday'],
        ['💰', 'Prosperity Night', 'Last Day of Every Month', 'A special service to close each month in God\'s covenant of prosperity. Come with your testimonies and expectation for blessings.', 'Monthly · Last Day'],
        ['🫒', 'Anointing Service', 'First Sunday of Every Month', 'A sacred service of the anointing oil for healing, consecration and divine favour. Bring your containers for anointing.', 'Monthly · First Sunday'],
      ];
      foreach($monthly as $m):
      ?>
      <div class="program-card" style="border-left-width:5px;">
        <div class="program-card-icon"><?php echo $m[0]; ?></div>
        <h3><?php echo $m[1]; ?></h3>
        <p><?php echo $m[3]; ?></p>
        <span class="time"><?php echo $m[4]; ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section style="background:var(--white); padding:80px 2rem;">
  <div class="section-inner">
    <p class="section-label">Coming Up</p>
    <h2 class="section-title">Upcoming <span class="accent">Events 2026</span></h2>
    <div class="divider"></div>

    <?php
    $events = [
      ['07', 'Mar', 'First Friday Salvation Night', 'National Secretariat, Abule-Egba', '10:00pm – Dawn', 'Monthly all-night prayer and salvation service. Come expecting a miracle encounter with God.'],
      ['28', 'Mar', 'Prosperity Night', 'National Secretariat, Abule-Egba', '6:00pm – 9:00pm', 'March end-of-month prosperity service. Celebrating God\'s covenant faithfulness.'],
      ['06', 'Apr', 'Easter Revival Services', 'All CAMC Branches', 'Good Friday & Easter Sunday', 'Special Easter revival services across all branches. A season of resurrection power.'],
      ['23', 'Sep', 'Annual Covenant of Prosperity Revival', 'National Secretariat, Abule-Egba', 'Multi-day Event', 'The flagship annual revival commemorating the Covenant of Prosperity established September 23, 2001. Expect mighty miracles!'],
      ['13', 'Dec', '73rd Founding Anniversary', 'National Secretariat, Abule-Egba', 'Full-day Celebration', 'Celebrating 73 years of God\'s faithfulness to CAMC since December 13, 1952.'],
    ];
    foreach($events as $ev):
    ?>
    <div class="event-item">
      <div class="event-date-box">
        <div class="day"><?php echo $ev[0]; ?></div>
        <div class="month"><?php echo $ev[1]; ?></div>
      </div>
      <div class="event-info">
        <h3><?php echo htmlspecialchars($ev[2]); ?></h3>
        <div class="event-meta">📍 <?php echo $ev[3]; ?> &nbsp;|&nbsp; 🕐 <?php echo $ev[4]; ?></div>
        <p><?php echo htmlspecialchars($ev[5]); ?></p>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- PHOTO SECTION with gallery photos -->
<section style="background:var(--navy); padding:80px 2rem;">
  <div class="section-inner">
    <p class="section-label" style="color:var(--gold);">January Salvation Vigil 2026</p>
    <h2 class="section-title" style="color:var(--white);">Event <span class="accent">Highlights</span></h2>
    <div class="divider center"></div>
    <div class="gallery-grid" style="margin-top:2rem;">
      <?php
      $imgs = ['DSC_1368.jpg', 'DSC_1381.jpg', 'DSC_1384.jpg', 'DSC_1393.jpg', 'DSC_1396.jpg', 'DSC_1439.jpg'];
      $captions = ['Woman in prayer', 'Praise team drummer', 'Saxophonists', 'Leadership platform', 'President worshipping', 'Choir and dancers'];
      foreach($imgs as $i => $img):
      ?>
      <div class="gallery-item">
        <img src="../assets/images/<?php echo $img; ?>" alt="<?php echo $captions[$i]; ?>" loading="lazy">
        <div class="gallery-overlay"><?php echo $captions[$i]; ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center; margin-top:2rem;">
      <a href="gallery.php" class="btn btn-gold">View Full Gallery</a>
    </div>
  </div>
</section>

<?php include '../includes/footer.php'; ?>
